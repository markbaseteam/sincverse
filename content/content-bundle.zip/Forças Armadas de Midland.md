up:: [[Departamento de Defesa de Midland]] 
tags:: #organizações #antagonistas 

# Forças Armadas de Midland

As Forças Armadas de [[Midland]] estão vinculadas ao [[Departamento de Defesa de Midland]]

- Ramos das Forças Armadas 
	- [[Exército de Midland|Exército de Midland]]
	- [[Força Aérea de Midland]] 
	- [[Marinha de Midland]]

## Background 

Em razão do seu status de protetorado do [[World-Empire]], Midland é em tese protegida pelas [[Forças Armadas Reais]], logo, o [[Governo de Midland|governo]] de Midland é obrigada a manter as suas Forças Armadas com baixo efetivo militar 

Em razão disso que o governo de Midland conta com o [[BCW]] 

## Outros

[[Academia Militar do Glass Lake]] 
