up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários #antagonistas 

# TJ Rutherford

Timothy James “TJ” Rutherford faz parte do [[Escudo]] 

[[Midland]]

## Infobox 

**Nome**:: Rutherford
**Apelido**:: TJ
**Gênero**:: Homem
**Sexualidade**:: Ace
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aparência

TJ é alto e magricela, com jeito desengonçado, branco, com cabelos compridos e loiros, olhos verdes, nariz arrebitado e lábios carnudos. Ele em geral veste roupas folgadas, vários números acima do seu, com o seu manto por cima

## Personalidade

TJ é fraco para dor

## Background

Por ter nascido num berço de ouro, TJ não tinha amigos e os seus pais eram distantes. Ele tinha apenas seus brinquedos como amigos. Por isso mesmo, ele já adulto era infantil e imaturo. Como consequência disso tudo, ele desenvolveu inconscientemente o seu poder. 

## Aptidões e poderes

### Fluxo

**Grandes quantidades de fluxo:** Depois do Madison, o TJ é a pessoa com a maior quantidade de [[Fluxo]] dentro do Escudo

### Toy Story 

[[Toy Story]]

## Batalhas

- **TJ** vs. [[Alex Drake]]
- TJ vs. **[[Jolie Boyer]]**

## Trivia

- Hoje, ele é classificado como [[Graus#^3726df|Grau Mediano]]
- Embora tenha quantidades obscenas de Fluxo, a sua quantidade não chega nem perto do [[Thomas Madison]], em razão da sua mutação 

