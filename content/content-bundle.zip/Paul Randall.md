up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Paul Randall

Anteriormente, Paul Randall era um capitão do [[Exército de Midland]] de [[Midland]]

[[Kieran Wood]]
[[Prisão de Segurança Máxima]]

## Infobox 

**Nome**:: Paul Randall
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::
