up:: [[Mapa dos Personagens]]
tags:: #personagens/terciários 

# Reginald

[[Frente Rebelde]]
[[LEA]]
[[Ethan Nightshade]]
[[Adjudicador]]

## Infobox 

**Nome**:: Reginald
**Apelido**:: Marvelous Reggie
**Gênero**:: Homem
**Sexualidade**:: Gay
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: "Frente Rebelde", "LEA"
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Diretor da LEA