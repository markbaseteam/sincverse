up:: [[Mapa dos Personagens]]
tags:: #personagens 

# Helen

[[Frente Rebelde]]

## Infobox 

**Nome**:: Helen 
**Apelido**::
**Gênero**:: Mulher (trans)
**Sexualidade**:: Hetero
**Idade**:: 20
**Nascimento**:: 980
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::