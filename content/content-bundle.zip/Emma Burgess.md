up:: [[Mapa dos Personagens]]
tags:: #personagens/principais 

# Emma Burgess

[[Frente Rebelde]] 
[[SOC]] 
[[Alex Drake]] 
[[William Woodman]] 
[[Jolie Boyer]]

## Infobox 

**Nome**:: Emma Burgess
**Apelido**:: Em
**Gênero**:: Mulher 
**Sexualidade**:: Hetero
**Idade**:: 24 anos
**Nascimento**:: 976
**Status**:: Viva
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::