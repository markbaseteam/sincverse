up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Killian

[[Frente Rebelde]]

## Infobox

**Nome**:: Killian
**Apelido**::
**Gênero**:: Queer
**Sexualidade**:: Queer
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::