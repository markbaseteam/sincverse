up:: [[Frente Rebelde]]
tags:: #organizações 

# Comitê Executivo da Frente Rebelde

O Comitê Executivo da Frente Rebelde é a instância dentro da [[Frente Rebelde]] responsável por cuidar do dia a dia 

É chefiado pelo [[Presidente|presidente]] e pelo seu Gabinete

O Comitê Executivo é eleito pelo [[Conselho Geral da Frente Rebelde]] 

## Estrutura

- [[Departamento de Operações Militares da Frente Rebelde]]
- [[Departamento de Inteligência da Frente Rebelde]]
- [[Departamento do Tesouro]]
- [[Departamento de Logística da Frente Rebelde]]
- [[Departamento de Infraestrutura]]

## Enredo 

Hoje, [[Nathanaël Lamoureux]] está a frente do Comitê Executivo

Depois do Black Jack ser assassino, a [[Joanna Nettles]] vai suceder ele a frente do Comitê Executivo. Embora o Newt junto à [[Facção Bergerista]] tente impedir 

