up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Noel Drake

Noel é filho do [[Adam Drake]] 

Noel é o amante da [[Celine Duguay]] 

Noel é o pai do [[Alex Drake]] 

Noel cresceu com o [[Louis Carpenter]] 

Noel era amigo da [[Bailey]], [[Benjamin Wheeler]] e [[Jude Tepes]]

Judah era o Chefe de Estado-Maior da [[Frente Rebelde]] 

## Infobox 

nome:: Noel Drake 
aka::
gênero::
sexualidade::
idade::
nascimento::
status:: 
afiliações::  
ocupações:: 
