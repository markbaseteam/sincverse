up:: [[Sobre Arquivos]]
tags:: #arquivos

# Visão Global

## Protótipo da Linha do Tempo

- Nascimento do Adam Drake → depois de 900 e antes de 910
- Entrada do Adam Drake na Universidade → Entre 925 e 930
- Grande Guerra → 930 a 935
- Governo Provisório → de 935 a mais de 940 (talvez 945?)
- Nascimento da Viola Spencer → mais de 920 e menos de 940
- Ditadura do Gabriel → por volta de 950 a 970
- Nascimento do Amos Birdy → por volta de 950
- Nascimento do Noel Drake → entre 950 e 970
- Nascimento do Kieran Wood → 958
- Fundação da Frente Rebelde → 970
- Morte do Adam Drake → entre 970 e 980
- Nascimento do Alex Drake → 980
- Morte do Noel Drake → 992

## Linha do Tempo da Frente Rebelde

- Fundação → 970
- Eleição do Adam Drake como primeiro Chairman → 970
- Morte do Adam Drake → entre 970 e 980
- Eleição de X como segundo Chairman → entre 970 e 980
- Eleição de Y como terceiro Chairman → entre 980 e 990
- Eleição do Noel Drake como quarto Chairman →entre 980 e 992
- Morte do Noel Drake → 992
- Eleição do Blackjack como quinto Chairman → 992

## Comparação entre o Governo Provisório e a Ditadura do Gabriel

Embora o Ditadura de Gabriel tenha sido horrível, tendo sido responsável pela morte e tortura de milhares de pessoas, ele não é nada comparado quando comparado ao Governo Provisório, mbora ele não tenha sido responsável diretamente pela morte ou tortura de tanta gente

O regime do Gabriel conseguiu industrializar o país num nível em que ele era capaz de competir com as outras potências mundias. Além de praticamente reduzir com a fome e o analfabetismo do país num nível que ninguém jamais havia visto antes. Ele simplesmente modernizou o país inteiro, transformando o país mais fodido do continente num dos mais poderosos, graças principalmente a sua política belicista 

Mas o regime do Scorza não era nem de longe alguém tão agradável assim, ele fundou campos de concentração, onde os presos eram obrigados a trabalhar pesado em troca do pagamento da sua própria “estadia” na prisão, num regime semelhante a escravidão. Fora isso, ele não só ampliou o efetivo de policias, como também deu a eles mais armas, com maior poder de fogo, além de conceder a eles poderes de juiz, júri e carrasco, contribuindo para que a violência policial simplesmente subisse nas alturas

E como o Governo Provisório caiu tão relativamente fácil,  mas o regime do Scorza não?  Simples,  apoio popular. Fora os traidores de sangue, o Governo Provisório não tinha apoio popular, enquanto que o regime do G embora não fosse tão adorado assim pelas grandes massas, era apoiado pela classe média de Midland 

O regime do Scorza ficou igualmente conhecido pela sua perseguição aos traidores de sangue, termo que fora cunhado pelo próprio Gabriel Scorza

Mas em contrapartida, o regime do Scorza expandiu o número de universidades, além de ter facilitado o acesso a elas. Ele construiu escolas pela extensão inteira de Midland, instituindo que o ensino era obrigatório para crianças e adolescentes

## Medidas da Ditadura do Scorza

- Industrialização do país
- Perseguição aos Bloodtraitors
- Instituição do midlandês como a única língua oficial
- Realização de grandes obras públicas
- Diminuição do índice de fome, pobreza e miséria
- Construção de mais universidade pelo país
- Facilitação da entradas das camadas mais baixas da sociedade nas universidade
- Instituição do ensino obrigatório por crianças e adolescentes
- Diminuição do índice de analfabetismo
- Fundação da Organização de Vigilância e Repressão aos Opositores da Pátria (OVROP)
- Perseguição a minorias étnicas
- Perseguição a dissidentes e opositores políticos
- Construção de campos de trabalho forçado