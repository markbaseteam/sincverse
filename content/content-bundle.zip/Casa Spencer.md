up:: [[Mapa do Mundo]]
tags:: #mundo 

# Casa Spencer

Os Spencer eram nobres de menor importância de [[Midland]]

Eles faziam parte de um dos conselhos provinciais de Midland

Quando Midland foi repartida, os Spencer conseguiram manter os seus títulos, embora tenham perdido todos os seus privilégios e riquezas 

Com a ascensão do Gabriel Scorza, os Spencer enriqueceram, já que o seu patriarca estava no círculo íntimo do Scorza

## Casa Spencer no último século 

[[Viola Spencer]]
[[Richard Spencer]]