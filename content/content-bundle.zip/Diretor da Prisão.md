up:: [[Mapa dos Personagens]] 
tags:: #personagens/terciários #antagonistas  

# Diretor da Prisão

[[Midland]]
[[Governo de Midland]]
[[Prisão de Segurança Máxima]]

É executado depois da [[Fuga da Prisão|fuga em massa]] ocorrida por causa do [[Kieran Wood]] e [[Paul Randall]] 