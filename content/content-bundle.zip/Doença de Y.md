up:: [[Mapa do Mundo]]
tags:: #mundo/doenças  

# Doença de Y

[[Vírus X]]
[[Pandemia do X]]
[[Órfãos de Y]]

## [[Órfãos de Y]] 

- [[Charles Babineaux]]