up:: [[Forças Armadas Reais]]
tags:: #organizações #antagonistas 

# Exército Real de World-Empire

O Exército Real do [[World-Empire]] é o braço armado das [[Forças Armadas Reais]] responsável pelas missões nas terras emersas

## Hierarquia

## Antigos  Oficiais

- [[Adam Drake]]