up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários

# Raymond Carter

[[Frente Rebelde]] 

## Infobox

**Nome**:: Raymond Carter
**Apelido**:: Ray
**Gênero**:: Homem 
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aparência 

## Personalidade

## Background

## Enredo

## Perícias e poderes

[[The Pied Piper]]

## Batalhas e Competições

## Trivia



