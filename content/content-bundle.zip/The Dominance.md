---
COM: B
PD: A
PO: X
PRA: E
UTI: A
VER: A
---
up:: [[Índice de Poderes]]
tags:: #poderes 
user:: [[Alicia Huxley]]

# The Dominance

[[Alicia Huxley]] e [[Poder|Poder]]

## Descrição 

O único requisito para a ativação do seu poder é a subjugação do seu alvo.  Assim que ela estiver certeza de que o alvo está devidamente subjugado, ela é capaz de pegar o que quiser das pessoas dominadas, a quem ela convenientemente chama de 'escravos', incluindo coisas tangíveis, coisas intangíveis (como sentidos e memórias) e até mesmo coisas que são abstratas (como guarda de crianças ou livre arbítrio).  Tudo o que o escravo possui pode ser levado por ela, e a partir desse momento, ela o usa como se fosse seu.

A definição de "ser subjugado" depende apenas do que ela considera como tal.

No entanto, se o alvo não tiver sido realmente subjugado, ela sofrerá o efeito rebote do seu próprio poder.