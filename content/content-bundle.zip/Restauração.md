up:: [[Mapa do Mundo]]
tags:: #mundo 

# Restauração

## Contexto

Depois do fim da [[Grande Grande Grande Guerra]], a [[CWP]] recebe o papel de solucionar o problema que era [[Midland]] 

A CWP decide então por reinstalar a antiga [[Casa Adrianus|Casa Real de Midland]] no poder, sem antes entrevistar a população 

Entretanto, a verdade era que a CWP usava a Casa Real como fantoche para que assim pudesse controlar Midland por debaixo dos panos 

## Período 

O interior do país estava num regime praticamente feudal 

Não houve qualquer tentativa de construção do país depois da Grande Grande Grande Guerra 

O Rei governava apenas para sua corte e deixava o interior do país ao Deus dará 

Dicotomia entre a população rural e urbana 

A Monarquia não procura industrializar o país 

O crime vai explodir no interior em consequência da sua condição social 

Os crimes da Monarquia eram denunciados pelo jornal [[Vontade Popular]], em especial pelo jornalista [[Gabriel Bosco]]

Junto do [[Adam Drake|Adam]], o Gabriel fundou o [[NML]], em busca de depor a Monarquia e realmente governar para o povo

## Fim

A Restauração encontraria o seu fim na [[Revolução das Romãs]]

## Veja Mais

- [[MRM]]
- [[Adrianus]]




