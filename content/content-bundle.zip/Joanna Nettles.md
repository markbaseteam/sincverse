up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Joanna Nettles

Joana Nettles era a Chefe do [[Departamento de Logística da Frente Rebelde]] da [[Frente Rebelde]] durante o mandato do [[Nathanaël Lamoureux]]

Depois da morte do Black Jack, ela é eleita a [[Presidente|presidente]] da RF no meio do conflito contra a [[Facção Bergerista]] do [[Newt]]

## Infobox 

**Nome**:: Joanna Nettles 
**Apelido**:: 
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Viva
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde
**Ocupações-Antigas**:: Chefe do Departamento de Logística 
**Ocupações-Atuais**:: Presidente 

## Background 

Antes de ter entrado na RF, a Joanna fazia parte do [[Exército de Midland]] de [[Midland]], mas eventualmente desertou 