---
COM: C
PD: C
PO: C
PRA: B
UTI: B
VER: B
---
up:: [[Índice de Poderes]]
tags:: #poderes
user:: [[Monica Armstrong-Boothman]]

# Manipulação de Cabelo

Manipulação de Cabelo é o [[Poder|poder]] da [[Monica Armstrong-Boothman]] 

## Descrição

Como o nome diz, através desse poder, a Madeline é capaz de manipular o seu cabelo livremente

- Fazer o seu cabelo crescer mais rápido;
- Moldar o seu cabelo em diferentes formatos; 
- Usar o seu cabelo como órgão sensorial;
