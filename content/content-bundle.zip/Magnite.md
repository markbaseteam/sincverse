up:: [[Mapa do Mundo]] 
tags:: #mundo/artefato 


# Magnite

Magnite é provavelmente a matéria-prima mais importante e relevante do mundo 

[[Midland]] é o país com as maiores reservas de Magnite, por isso, o interesse do [[World-Empire]] e [[CWP]]

Magnite é profundamente relacionado com a [[Magia]]