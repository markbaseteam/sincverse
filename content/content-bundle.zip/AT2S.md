up:: [[Conselho Geral da Frente Rebelde]]
tags:: #organizações #antagonistas 

# AT2S

Esquadrão Especializado em Táticas Alternativas (Alternative Tactics Specialized Squad) é a unidade de elite da [[Frente Rebelde]] que está sob o comando do [[Conselho Geral da Frente Rebelde]], mais especificamente do [[Richard Stillwell]]

## Pessoal

- [[Louis Carpenter]]

## Passado 

Anteriormente, o [[Jude Tepes]] fez parte do AT2S, tendo recebido a missão de espionar o [[Noel Drake]]
