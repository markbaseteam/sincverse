up:: [[Magia]]
tags:: #mundo/conceitos #magia 

# Técnicas Inatas

[[Magia]]
[[Poder]]

