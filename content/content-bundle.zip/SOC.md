up:: [[Departamento de Operações Militares da Frente Rebelde]]
tags:: #organizações 

# SOC

O Comando de Operações Especiais (SOC) da [[Frente Rebelde]] é o comando dentro do [[Departamento de Operações Militares da Frente Rebelde]] que é responsável pelas operações especiais 

## Staff

- [[Patchwork]]
- [[Emma Burgess]]
- [[Patrick Fisk]]
- [[Edmund Page]]
- [[Daniel Hawbrough]]
- [[Alex Drake]]
- [[William Woodman]]
- [[Jolie Boyer]]