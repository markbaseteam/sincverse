up:: [[Magia]]
tags:: #mundo/conceitos #magia 

# Geister

Geister é a manifestação física da psíque de quem o sumonou 

[[Magia]]

## Casos 

- A mãe do [[Thomas Madison]] 