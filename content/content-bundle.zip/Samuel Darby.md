up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários  #antagonistas 

# Samuel Darby

Samuel Darby faz parte do [[Escudo]], mas secretamente ele é o diretor da [[Phantom Troupe]]

## Infobox 

**Nome**:: Samuel Darby
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: "Phantom Troupe", "Escudo"
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Diretor da Phantom Troupe