up:: [[Departamento de Defesa de Midland]]
tags:: #organizações 

# Academia Militar do Glass Lake

A Academia Militar do [[Glass Lake]] é a instituição de [[Midland]] responsável pelo treinamento dos oficiais comissionados das [[Forças Armadas de Midland|Forças Armadas de Midland]] 

## Ex-alunos 

- [[Carl Jager]]
- [[Thomas Madison]] 
- [[Thomas Starkweather]] 

