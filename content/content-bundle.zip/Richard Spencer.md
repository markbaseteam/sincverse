up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas 

# Richard Spencer

Richard Spencer é o Diretor-adjunto do [[Escudo]] 

## Infobox

**Nome**:: Richard Spencer 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Diretor-Adjunto

# Personalidade

Richard é arrogante, egocêntrico e egoísta. Richard é machista e misógino. Richard gosta de pisar em que ele acha que ele é inferior, isso é, quase o mundo inteiro 

## Background 

Richard faz parte do [[Casa Spencer]] 

Ele é o sobrinho da [[Viola Spencer]] 