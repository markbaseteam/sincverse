up:: [[Submundo]]
tags:: #organizações #submundo

# Casa de Leilões

A Casa de Leilões é a organização responsável pelos maiores, mais importantes e relevantes leilões do [[Submundo]]

[[Comissão]] 

## Clientes 

- [[Kieran Wood]]

## Vendedores 

