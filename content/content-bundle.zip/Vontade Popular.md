up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários

# Viola Spencer

Viola é a mestra do [[Alex Drake]] 

## Infobox 

nome:: Viola Spencer
aka::
gênero:: Mulher
sexualidade:: Hetero
idade::
nascimento::
status:: Vivo
afiliações:: 
ocupações:: 

## Background

Viola fundou o [[We Stand]] junto de colegas seus com o objetivo de combater o regime do Scorza. Mais tarde com a dissolução do We Stand, a Viola decidiu entrar para a [[Frente Rebelde]], sendo fundamental para ela pelo menos até a sua saída, depois da morte do seu filho único 

Como ninguém sabia quem é o pai do Alexander, há teorias de que o [[Adam Drake]] era o pai da criança

[[Universidade de World-Empire]] 