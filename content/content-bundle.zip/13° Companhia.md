---
categoria: organização 
---
up:: [[Exército de Midland]]
tags:: #organizações #antagonistas

# 13° Companhia

A 13° Companhia do [[Exército de Midland]] de [[Midland]] é famoso por ser supostamente amaldiçoada

## Capitães

- [[Blaise Delacroix]]