up:: [[Frente Rebelde]]
tags:: #organizações 

# Conselho Geral da Frente Rebelde

O Conselho Geral da Frente Rebelde é o órgão responsável pela nomeação, fiscalização e demissão do [[Presidente|presidente]] da [[Frente Rebelde]]

Os participantes do Conselho Geral são nomeados pelo [[Congresso da Frente Rebelde]]

## Conselheiros 

### Antes

- [[Richard Stillwell]]

### Depois 

- [[Amos Keen]]

## Unidades

[[AT2S]]
