up:: [[Mapa dos Antagonistas]]
tags:: #personagens/principais #antagonistas 

# Jude Tepes

Jude Tepes é o antagonista central do Vengeance já que ele é o assassino do [[Noel Drake]]

Jude hoje é o Diretor do [[BCW]]

Jude deseja morrer pelas mãos do [[Alex Drake]] 

Jude era amigo da [[Bailey]] e do [[Benjamin Wheeler]]

## Infobox 

**Nome**:: Jude Tepes
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: Frente Rebelde 
**Afiliações-Atuais**:: BCW
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Diretor

## Background 

Jude faz parte da [[Casa Tepes]]

Jude nasceu com [[Mudblood]] assim como o resto da Casa Tepes, logo, ele sempre conviveu com o medo de ser obrigado a ir viver no [[Moonlit Gardens]]

Antes do Jude assumir como Diretor do BCW, a [[Lady Nagant]] era a Diretora do BCW

Jude fazia parte da [[Frente Rebelde]]  ([[AT2S]]) antes de ir para o lado do [[Governo de Midland]] 

Jude é manipulado pelo [[Kieran Wood]]

## Combates

- **Jude Tepes** VS. [[Louis Carpenter]]
- Jude Tepes VS. [[Zelda Creed]]