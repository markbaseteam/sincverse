up:: [[Suprema Corte da Frente Rebelde]]
tags:: #cargo

# Adjudicador

O Adjudicador é a pessoa responsável pelo poder judiciário dentro da [[Frente Rebelde]]. O Adjudicador é a figura central da [[Suprema Corte da Frente Rebelde]] 

O Adjudicador é a corregedoria da Frente Rebelde

O Adjudicador comanda o [[LEA]]

## Relação de Adjudicadores

- [[Agnes Crawford]]