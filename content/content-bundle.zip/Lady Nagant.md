up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Lady Nagant

Lady Nagant era a Diretora do [[BCW]] antes de ser presa e encarcerada na [[Prisão de Segurança Máxima]] 

## Infobox 

**Nome**::
**Apelido**:: Lady Nagant
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Viva
**Afiliações-Anteriores**:: BCW
**Afiliações-Atuais**:: Spear
**Ocupações-Antigas**:: Diretora
**Ocupações-Atuais**:: Diretora

## Background 

Antes do [[Jude Tepes]], a Lady Nagant era a Diretora do BCW, mas por motivos desconhecidos ela acabou sendo preso

## Enredo

Durante a [[Fuga da Prisão|fuga em massa]], a Lady Nagant consegue fugir da prisão, assassinando outros prisioneiros no meio do caminho 

Entretanto, inusitadamente, a Lady Nagant voltou e propôs ao [[Governo de Midland|governo]] de [[Midland]] os seus serviços, assim criando a [[Spear]] 

[[Kieran Wood|Kieran]] envia o [[Louis Drake|Louis]] para assassinar a Lady Nagant. Quando a Lady Nagant vê o Louis, ela decide recuar, por que era o mais sensato 

## Aptidões e poderes

Embora seja poderosa, a Lady Nagant sabe dos seus limites

## Trivia