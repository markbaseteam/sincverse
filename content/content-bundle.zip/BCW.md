up:: [[Governo de Midland]]
tags:: #organizações #antagonistas 

# BCW

O Escritório do Bem-Estar Comum (ou simplesmente BCW) é ao mesmo tempo o serviço doméstico de segurança de [[Midland]] e a sua principal agência de aplicação da lei  

O Diretor hoje do BCW é o [[Jude Tepes]] 

## Objetivo

- aplicação da lei em Midland 

## Divisão

- [[Escudo|Seção 172]]
- [[Spear|Seção 646]]
- [[Quatro Ases|Seção 666]]
- [[Seção 999]]

## Outros

- [[Programa de Recrutamento de Órfãos]]
- [[Graus]]

