up:: [[Mapa das Organizações]]
tags:: #organizações #antagonistas 

# MRM

O Movimento pela Restauração da Monarquia (ou simplesmente MRM) é a organização que busca a restauração da monarquia em [[Midland]] 

