up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Bailey

A Bailey era a melhor amiga do [[Noel Drake]]

## Infobox 

**Nome**:: Bailey
**Apelido**::
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Falecida
**Afiliações-Anteriores**:: Frente Rebelde 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Biografia 

Bailey fazia parte do Comitê Executivo da [[Frente Rebelde]] 

Bailey criou o [[Alex Drake]]

Bailey é assassinada pelo [[Kieran Wood]] 

Inicialmente,  o Alex acredita que a Bailey havia sido assassinada pelo [[Jude Tepes]] 

[[Benjamin Wheeler]]

