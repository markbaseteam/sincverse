up:: [[Mapa dos Conceitos]]
tags:: #conceitos 

# Graus

O [[Governo de Midland|governo de Midland]] classifica os agentes do [[BCW]] em 4 graus de acordo com o seu poder

[[Escudo]]
[[Spear]]
[[Quatro Ases]]
[[Seção 999]]


## Índex 

### Grau Especial

^7bbd8a

##### Escudo

- [[Arthur Weston]]
- [[Thomas Madison]]

##### Outros

- [[Amos Birdy]] 
- [[Jude Tepes]]

### Grau Superior

#### Plus

##### Escudo

- [[Cain Earnshaw]] 
- [[Charles Babineaux]]
- [[CJ Drake]]
- [[Monica Armstrong-Boothman]]
- [[Richard Spencer]]

##### Ases

- [[Edward Turner]]

#### Normal

##### Escudo

^3726df

- [[Daniel Weston]]
- [[Draco]]
- [[John Starkweather]]
- [[Samuel Darby]]
- [[TJ Rutherford]]
- [[Thomas Heatherwick]]

### Grau Médio

##### Escudo 

- [[Eli Weston]]

### Grau Inferior

## Veja mais 

- [[NP]] 