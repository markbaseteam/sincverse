up:: [[Mapa do Mundo]]
tags:: #mundo 

# Ditadura do Kirk

[[NML]]
[[Gabriel Bosco]]
[[Regime do Bosco]]
[[Nicholas Kirk]]
[[Adam Drake]]
[[We Stand]]
[[Viola Spencer]]
[[Midland]]
[[Amos Birdy]]