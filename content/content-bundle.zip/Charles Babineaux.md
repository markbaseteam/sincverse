up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas 

# Charles Babineaux

Charles L. Babibeaux faz parte do [[Escudo]]

## Infobox 

**Nome**:: Charles Lucas Babineaux 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aparência

Charles

## Personalidade

Charles sofre com toc de contaminação

Charles é escorregadio, traiçoeiro, falso e pérfido

Charles é fútil, superficial, dissimulado e frívolo

Charles é adulador, escorregadio, evasivo e esquivo

## Background

Como o pai do Charles trabalhava para o regime do Gabriel, eles eram bem de vida, vivendo numa casa grande e num bairro tranquilo

Mais tarde, quando o Charles já estava na sua adolescência, [[Midland]] seria atingida pela [[Pandemia do X|pandemia do vírus X]] e dentre quem morreu estava os pais do Charles. Por sinal, o número de mortos era simplesmente fora da realidade, sem quaisquer precedentes

Os órfãos por causa do [[Vírus X|vírus X]] eram popularmente chamados de "[[Órfãos de Y|órfãos de Y]]"

Como o Charles estava sem pais, ele acabou indo morar em abrigos publicos, onde viveu por meses a fio, quando mais tarde enfim seria levado para o orfanato mais próximo que não estivesse simplesmente abarrotado de crianças

Os abrigos de Midland eram usados como lares temporários e permanentes para pessoas em situação de rua ou semelhantes, por isso eram abarrotados de gente, fazendo com que não houvesse qualquer espécie de privacidade ou limpeza 

A soma das tragédias que o Charles vivenciou fez com ele ficasse obcecado com contaminação e limpeza, fazendo com que ele desenvolvesse o seu toc de contaminação 

Mais tarde, o Charles seria recrutado pelo [[Programa de Recrutamento de Órfãos|programa de Midland]] que recrutava jovens órfãos para o [[BCW]]

## Enredo

Charles é fiel ao [[Thomas Madison]]

Charles geralmente faz dupla com [[Monica Armstrong-Boothman]]

## Perícias e poderes

### Poder

Poder de longa distância + poder com temática em limpeza 

## Trivia

- As iniciais de **C**harles **L.** **B**abineaux vão remeter ao inventor da água sanitária, [Claude Louis Bertoleti](https://en.m.wikipedia.org/wiki/Claude_Louis_Bertoleti)

