up:: [[Mapa do Mundo]]
tags:: #mundo/eventos

# Pandemia do X

[[Vírus X]]
[[Midland]]
[[Charles Babineaux]]
[[Órfãos de Y]]

## Background

A pandemia da [[Doença de Y]] atingiu [[Midland]] e dizimou dezenas de milhares de pessoas

O [[Governo de Midland|governo de Midland]] enfrentou a pandemia do pior jeito possível 