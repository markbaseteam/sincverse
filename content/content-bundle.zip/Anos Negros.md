up:: [[Mapa do Mundo]]
tags:: #mundo 

# Anos Negros

Termo cunhado pelo [[Gabriel Bosco]] para fazer referência ao período em que [[Midland]] estava repartida entre 3 nações: [[World-Empire]], N1 e N2

[[Traidores de Sangue]]