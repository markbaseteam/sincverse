up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Carl Jager

Carl J é um ex-capitão do [[Exército de Midland]]

[[Casa Jager]]

[[Midland]] 

[[Academia Militar do Glass Lake]]

## Infobox

**Nome**:: Carl Jager
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: Exército de Midland 
**Afiliações-Atuais**:: The Stench
**Ocupações-Antigas**:: Capitão 
**Ocupações-Atuais**::

## Aparência

O corpo do Carl é deformado com o tanto de cicatrizes das torturas que ele sofreu nas mãos do Shelley. A única parte do seu corpo sem nenhuma cicatriz é o seu rosto

O Carl é bonito, com tez cor de oliva, rosto quadrado, cabelos pretos, olhos castanhos e nariz reto. Antes de ser preso por Midland, Carl mantinha o seu rosto perfeitamente barbeado e o cabelo cortado curto. Depois de ter passado anos na prisão, o seu cabelo e barba estão fora do controle 

## Background

## Protótipo de Background

Carl era um jovem oficial do Exército de Midland. Ele era idealista, muito habilidoso e tinha um futuro promissor pela frente

Entretanto, por causa da sua personalidade idealista, o Carl entrava em conflito com superiores por conta das ordens que ele iam de encontro com a sua visão de mundo, fazendo com que ele muitas vezes questionasse e desobedecesse as ordens

Por conta da sua indisciplina, o Carl era visto como problema, logo a sua unidade acabou sendo transferida para o comando do coronel Quincy 

O coronel Quincy enviou o Carl e a sua unidade numa missão suicida, onde eles serviriam como iscas, sem é claro que o Carl soubesse disso

A unidade do Carl acabou sendo cercado pelas forças da Frente Rebelde, com o Carl sem poder fazer nada enquanto via a sua unidade sendo quase que inteiramente massacrada. Em estado de choque, o Carl acabou sendo capturado pela RF para posterior interrogatório 

Carl foi torturado por semanas a fio pelo Thomas Shelley. À época, Shelley era diretor-adjunto da Unidade de Tortura e Interrogatório. Shelley era particularmente conhecido pela sua crueldade e sadismo excessivos, sendo mestre em técnicas de tortura física e psicológica

Embora ninguém gostasse muito do Shelley e houvesse várias ações legais contra ele por causa dos seus métodos doentios, a verdade era que o Shelley era muito eficaz e útil

Entretanto, Carl não cedeu a tortura do Shelley, ficando calado e não falando nada sobre o pouco que sabia. Por não ter cedido a tortura, o Carl se tornou um dos favoritos do Shelley e ser um dos favoritos do Shelley era um dos piores destinos possíveis

Os favoritos de Shelley eram torturados até que enlouquecessem, momento no qual eles perdiam a graça para ele, mas o Carl era diferente, não importava quanto o Shelley tentasse levar o Carl ao limite, ele não cedia  

Algum dia, ele conseguia fugir com outros prisioneiros. Ao voltar para as forças armadas, Carl descobriu que o Quincy havia o enviado naquela missão, pois sabia que ela era suicida, já que ele queria que o Carl morresse mesmo, tendo em vista que o Carl causava muita dor de cabeça para os superiores das forças armadas

Depois de saber dessa traição, o Carl ficou muito puto e matou o Quincy, saindo matando outros oficiais das forças armadas até ser preso

## Enredo

Carl é obrigado a entrar na [[Seção 999]], mas ele consegue eventualmente fugir, conhecendo o [[AJ]]

Mais tarde, Carl entra para o [[The Stench|Stench]]

## Veja mais

[[Thomas Shelley]]