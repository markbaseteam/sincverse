---
COM: "5"
CON: "5"
MAG: "1"
PD: "1"
PO: "1"
PRA: "5"
UTI: "4"
VER: "1"
---
up:: [[Índice de Poderes]]
tags:: #poderes
user:: [[Thomas Heatherwick]] 

# Battle Waltz

Battle Waltz é o [[Poder|poder]] do [[Thomas Heatherwick ]]

# Descrição

Através do Battle Waltz, Thomas é capaz de anular os efeitos do poder de outra pessoa, desde que ela esteja a menos de 9 metros do Thomas. O poder só funciona numa pessoa por vez
