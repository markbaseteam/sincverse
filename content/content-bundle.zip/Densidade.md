up:: [[Mapa dos Conceitos]]
tags:: #mundo/conceitos #magia 

# Densidade

[[Magia]]
[[Fluxo]]
