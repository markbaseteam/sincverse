up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Thomas Madison

Thomas Madison é o Diretor hoje do [[Escudo]]

## Infobox 

**Nome**:: Thomas Madison
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Diretor 

## Background

A mãe do Thomas amava tanto o seu filho que mesmo depois da sua morte o seu desejo de o proteger permaneceu, transcendendo a morte

A mãe do Thomas queria ter filhos 

A mãe do Thomas tinha problemas para ter filhos, já que caso ela tentasse, ela provavelmente viria a morrer. Mesmo sabendo disso tudo, ela decidiu engravidar e levar a gravidez para frente. Ao dar a luz, ela teve mais complicações e como era esperado, ela morreu, mas o seu filho veio ao mundo saudável 

O seu amor era tanto que ele superou as barreiras da morte e originou o daimon que protege o Thomas até hoje

Thomas Madison treinou na [[Academia Militar do Glass Lake|Academia Militar do Glass Lake]] e entrou para o [[Exército de Midland|Exército de Midland]] como Capitão 

Entretanto, mais tarde, ele dá baixa por causa de motivos pessoais, quando já era Major

Thomas enfrenta e suplanta o [[Arthur Weston]]

Thomas entra o Escudo com o intuito de ir subindo na hierarquia até chegar no cargo de Diretor do [[BCW]], para que assim pudesse mudar as coisas de dentro

## Aptidões e Poderes

Thomas é protegido pelo Geister criado pela sua mãe em seu desejo de sempre o proteger 

## Combates 

- **Thomas Madison** vs. Arthur Weston
- **Thomas Madison** vs. [[Adrianus]]
- Thomas Madison vs. **[[Louis Drake]]**

## Trivia

- O BCW rankeia o Thomas como [[Graus#^7bbd8a|Grau Especial]], sendo assim considerado como o cara mais poderoso do Escudo