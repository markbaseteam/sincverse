up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Cain Earnshaw

Cain Earnshaw faz parte do [[Escudo]]

## Infobox 

**Nome**:: Cain Earnshaw
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aparência

Os olhos do Cain são estranhamente azuis

## Personalidade

Cain crê ser amaldiçoado, só trazendo desgraça para quem ele ama. Ele é amargurado, com o seu senso de humor seco e cáustico 

## Background

Os pais do Cain eram camponeses paupérrimos de [[Midland]], com bocas demais  e comida de menos, sem nenhuma condição de criar ele por ser cego. Num dia, apareceu na fazenda dos seus pais alguém oferecendo dinheiro em troca do Cain. Sem pensar pela segunda vez, o pai do Cain vendeu ele para o cara, logo, o Cain nunca mais "viu" nem seu pai nem sua mãe

O cara que comprou o Cain o ensinou desde pequeno a compreender e perceber os seus arredores usando os seus outros sentidos, além de ter o ensinado a lutar, através de rotinas de treino exaustivas

Como o cara nunca falou o seu nome para o Cain, ele simplesmente o chamava de Him 

Cain nunca soube se o Him era cego que nem ele ou se ele era capaz de enxergar 

Him o ensinou a fazer tudo que tudo mundo que conseguia enxergar normalmente era capaz, incluindo por exemplo, escrever e caçar 

Entretanto, o Him não era nem gentil nem rude, tratando o Cain sempre de modo prático. Assim como nunca contou qual era seu nome, Him nunca contou para o Cain porque perdia o seu tempo com ele. Assim, o Him não era nada dado a conversas, falando só o que era estritamente necessário

## Enredo

Cain enfrenta, suplanta e executa o [[John Starkweather]]

Cain enfrenta o [[Alex Drake]]

Cain enfrenta e suplanta o [[Richard Spencer]]

## Aptidões e poderes 

Cain é surpreendentemente genial quando o assunto é [[Magia]]

Cain desenvolveu a [[Técnicas Básicas|técnica básica]] que permitia a ele usar o seu fluxo de energia ou densidade de energia como meio de fazer ecolocalização que nem morcegos 

## Batalhas e combates 

- **Cain Earnshaw** vs. John Starkweather 
- Cain Earnshaw vs. Alex Drake
- **Cain Earnshaw** vs. Richard Spencer 

## Trivia

- Cain nasceu cego