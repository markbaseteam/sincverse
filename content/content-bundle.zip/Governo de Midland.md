up:: [[Midland]]
tags:: #organizações #antagonistas 

# Governo de Midland

[[Midland]]

- [[BCW|Escritório de Bem-Estar Comum]] 
- [[CIB|Departamento Avançado de Inteligência]] 
- [[EAD|Departamento de Assuntos Extraordinários]]
- [[Departamento de Defesa de Midland]]