up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Edmund Metcalfe

Edmund Metcalfe fundou a [[Frente Rebelde]] junto do [[Adam Drake]] 

## Infobox

**Nome**:: Edmund Metcalfe 
**Apelido**:: 
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Falecido 
**Afiliações-Anteriores**:: Frente Rebelde 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: Presidente 
**Ocupações-Atuais**::

Edmund nasceu em [[Midland]] 

Edmund estudou na [[Universidade de World-Empire]]