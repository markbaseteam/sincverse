up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas 

# Percy Le Goff

Percival "Percy" Le Goff é o Diretor do [[EAD]] 

Percy é o principal inimigo do [[Kieran Wood]] 

## Infobox 

**Nome**:: Percy Le Goff
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: EAD
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Diretor

## Background

Percy é o representante do [[World-Empire]]  em [[Midland]] 





