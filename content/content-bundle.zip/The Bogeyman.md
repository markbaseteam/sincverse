up:: [[Submundo]]
tags:: #submundo/assassinos 

# The Bogeyman

The Bogeyman é o assassino de aluguel mais renomado do [[Submundo]]