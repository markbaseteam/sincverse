up:: [[Mapa das Organizações]] 
tags: #organizações 

# NML

Movimento Nacional pela Liberdade (NML) é a organização fundada pelo [[Adam Drake]] e [[Gabriel Bosco]] contra o [[CWP]] em busca da emancipação de Midland do [[Restauração]] 

[[Revolução das Romãs]]
