up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários #antagonistas 

# Edward Turner

Edward Turner é o Ás de Copas da [[Quatro Ases|Seção 666]]

## Infobox

**Nome**:: Edward Turner
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Seção 666 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Personalidade

Edward é educado e simpático. Mesmo tendo estado no mundo do crime por muitos anos, o Edward não perdeu o seu lado gentil e carinhoso. Embora o seu trabalho fosse literalmente executar pessoas, ele não gostava de machucar ou matar pessoas sem necessidade. Edward via o Tusk como a sua segunda casa e o boss como o seu pai, sendo completamente leal a eles. Ele ama os seus irmãos acima de tudo e de todos, incluindo a si mesmo, desejando para eles o melhor e como consequência disso ele não queria que nenhum dos seus irmãos precisasse entrar para o crime assim como ele entrou 

## Background

A mãe do Edward morreu quando ele tinha 18 anos e como ele nunca conheceu quem era o seu pai, o dever de cuidar dos seus irmãos mais novos caiu sobre os seus ombros. Em razão do contexto em que vivia, Edward acabou entrando para o mundo do crime

Edward entrou para os Sons of Sea

Já mais velho, o Edward trabalhava como guarda-costas do boss dos Sons of Sea

Os Sons of Sea não eram nem de longe a maior organização criminosa do sul de Midland, entretanto, a gangue crescia cada vez mais em influência e poder

O maior sindicato criminoso, com medo da crescente ascensão dos Sons of Sea, enviou assassinos para assassinar a cadeia de comando dos Sons of Sea. Como a tentativa não deu certo, o boss do sindicato inimigo voltou seus olhos para os parentes mais próximos da cadeia de comando dos Sons of Sea

Nesse meio tempo, o Edward acabou sendo preso numa operação realizada pelo [[BCW]], que visava prender o boss dos Sons of Sea. Como o Edward estava com medo da gangue inimiga matar seus irmãos, ele estava desesperado para sair da cadeia e proteger seus irmãos. Tentando entrar num acordo com as autoridades, ele propôs as autoridades vender o boss dos Sons of Sea para que ele pudesse sair da cadeia e fugir com os seus irmãos. Mas tudo deu errado, o BCW não só prendeu o boss dos Sons of Sea, mas também pegou os irmãos do Edward como refém, garantindo que o Edward fizesse tudo que o governo quisesse

Sem opções, o Edward acabou nas mãos do governo, sendo obrigado a entrar para os Seção 666 como o Ás de Copas. O acordo era simples, caso o Edward fracassasse em qualquer missão dos Quatro Ases, quem sofreria as consequências seria os irmãos do Edward

## Trivia

- Enquanto estava na vida do crime, o [[NP]] do Edward era B
- Edward é considerado como o segundo mais forte dos Quatro Ases

## Veja mais

[[Harborside]]
[[Sons of Sea]]