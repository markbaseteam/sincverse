up:: [[Comitê Executivo da Frente Rebelde]]
tags:: #organizações 

# Departamento de Operações Militares da Frente Rebelde

[[Frente Rebelde]] 
[[Comitê Executivo da Frente Rebelde]]
[[Aaron Montgomery]] 
[[SOC]]

