up:: [[Índice de Poderes]]
tags:: #poderes 
user:: 

# Stickers

[[Poder]] 

## Descrição 

Ele pode criar adesivos que quando postos em objetos ou partes do corpo, cria réplicas daquele objeto ou parte do corpo. Quando o adesivo é retirado ou destruído, a réplica é atraído ao original, sendo unida a ele com violência em seguida

## Análise 

### Eu 

COM:: 1
CON:: 5
MAG:: 2
PD:: 3
PO:: 2
PRA:: 5
UTI:: 3
VER:: 3

### Guilherme

com:: 0
con:: 0
mag:: 0
pd:: 0
po:: 0
pra:: 0
uti:: 0
ver:: 0

### Gráfico

```dataviewjs
const data = dv.current()
const chartData = {
	type: 'radar',
	data: {
		labels: ['COM','CON','MAG','PD','PO','PRA','UTI','VER'],
		datasets: [{
			label: 'Eu',
			data: [data.COM,data.CON, data.MAG,data.PD,data.PO,data.PRA,data.UTI,data.VER],
			fill: true,
		    backgroundColor: 'rgba(255, 0, 0, 0.25)',
		    borderColor: 'rgb(255, 99, 132)',
			pointBackgroundColor: 'rgb(255, 99, 132)',
		pointHoverBackgroundColor: '#fff',
		    pointHoverBorderColor: 'rgb(255, 99, 132)'}, {label: 'Guilherme',
    data: [data.com, data.con, data.mag, data.pd, data.po, data.pra, data.uti, data.ver],
    fill: true,
    backgroundColor: 'rgba(54, 162, 235, 0.2)',
    borderColor: 'rgb(54, 162, 235)',
    pointBackgroundColor: 'rgb(54, 162, 235)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgb(54, 162, 235)'
  }]},
	options: {
		scales: {
			r: {
				suggestedMin: 1,
				suggestedMax: 5
			}}
		}
};

window.renderChart(chartData, this.container);

```

## Veja mais 

[[Análise dos Poderes]] 