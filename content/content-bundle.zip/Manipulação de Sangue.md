up:: [[Índice de Poderes]]
tags:: #poderes 
user:: [[Alex Drake]]

# Manipulação de Sangue

Manipulação de Sangue é o [[Poder|poder]] do [[Alex Drake]]

## Descrição 

Alex é capaz de manipular o seu próprio sangue tanto internamente quanto externamente ao seu corpo

## Técnicas

### Overload

Ao elevar a sua temperatura corporal, pulsação e número de hemácias, o Alex consegue elevar a sua performance física para níveis excepcionais 

## Gráfico

### Eu

COM:: 2
CON:: 5
MAG:: 3
PD:: 4
PO:: 3
PRA:: 2
UTI:: 4
VER:: 3

## Primeira Tentativa

```chart
type: radar
labels: [COM,PD,PO,PRA,UTI,VER]
series:
  - title: Eu
    data: [2,3,3,2,4,2]
  - title: Guilherme
    data: [2,4,3,2,4,3]
rMax: 5
rMin: 0
width: 80%
```

## Segunda Tentativa 


```dataviewjs
const data = dv.current()
const chartData = {
	type: 'radar',
	data: {
		labels: ['COM','PD','PO','PRA','UTI','VER'],
		datasets: [{
			label: 'Eu',
			data: [data.COM,data.PD,data.PO,data.PRA,data.UTI,data.VER],
			fill: true,
		    backgroundColor: 'rgba(255, 0, 0, 0.25)',
		    borderColor: 'rgb(255, 99, 132)',
		    pointBackgroundColor: 'rgb(255, 99, 132)',
		    pointHoverBackgroundColor: '#fff',
		    pointHoverBorderColor: 'rgb(255, 99, 132)'}]},
	options: {
		scales: {
			r: {
				suggestedMin: 0,
				suggestedMax: 5
			}}
		}
}

window.renderChart(chartData, this.container);

```

## Terceira Tentativa 

```dataviewjs
const data = dv.current() 

dv.paragraph(`\`\`\`chart 
	type: radar 
	labels: [${'COM'},${'PD'},${'PO'},${'PRA'},${'UTI'},${'VER'}] 
	series: 
	- title: Eu
	  data: [${data.COM},${data.PD},${data.PO},${data.PRA},${data.UTI},${data.VER}]
	rMax: 5
	rMin: 0 
\`\`\``)
```

## Quarta Tentativa 

```dataviewjs

var data = dv.current()
var layout 

data = [{ 
	type: 'scatterpolar',
	name: 'Eu',
	showlegend: true,
	r: [data.COM, data.PD, data.PO, data.PRA, data.UTI, data.VER], 
	theta: ['COM','PD','PO', 'PRA', 'UTI', 'VER'], 
	fill: 'toself'
	 }] 
	
layout = { 
	polar: {
		angularaxis: {
			direction: "clockwise"}, 
		radialaxis: {
			visible: true, 
			range: [0, 5] } }
 }

window.renderPlotly(this.container, data, layout)
```

## Quinta Tentativa

```dataviewjs

const data = dv.current()

const option = {
  title: {
    text: 'Manipulação de Sangue'
  },
  legend: {
    data: ['Eu']
  },
  radar: {
    // shape: 'circle',
    indicator: [
      { name: 'COM', max: 5, min: 0 },
      { name: 'PD', max: 5, min: 0 },
      { name: 'PO', max: 5, min: 0 },
      { name: 'PRA', max: 5, min: 0 },
      { name: 'UTI', max: 5, min: 0 },
      { name: 'VER', max: 5, min: 0 }
    ]
  },
  series: [
    {
      name: 'Eu',
      type: 'radar',
      data: [
        {
          value: [data.COM, data.PD, data.PO, data.PRA, data.UTI, data.VER],
          name: 'Eu'
        }
      ]
    }
  ]
};

app.plugins.plugins['obsidian-echarts'].render(option, this.container)
```
