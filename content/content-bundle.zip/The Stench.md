up:: [[Mapa das Organizações]]
tags:: #organizações #antagonistas 

# The Stench

O objetivo do Stench é disseminar o mal entre a população de [[Midland]] 

O Stench é composto somente pela escória da escória 

A maioria dos Stench são novatos com relação aos seus [[Poder|poderes]]

# Staff

[[AJ]]
[[Carl Jager]] 
