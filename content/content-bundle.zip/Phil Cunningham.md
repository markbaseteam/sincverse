up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Phil Cunningham

Phil Cunningham faz parte do [[Escudo]]

## Infobox

**Nome**:: Phil Cunningham 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background 

Phil está relacionado à busca de vingança do [[William Woodman]]

## Poderes

[[Vanishing Cabinet]]