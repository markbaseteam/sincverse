up:: [[Forças Armadas de Midland]]
tags:: #organizações #antagonistas 

# Exército de Midland

O Exército é o braço das [[Forças Armadas de Midland]] em terras emersas 

[[Midland]]

[[Divisão de Operações Especiais de Midland]]

## Pessoal

### Coronel

### Tenente 

- [[Blaise Delacroix]]

## Aposentados, mortos, na reversa ou expulsos

- [[Thomas Madison]] (Major)
- [[Thomas Starkweather]] (Major-General)