up:: [[Midland]]
tags:: #mundo 

# Aristocracia

A aristocracia em [[Midland]] 

# Estrutura

- Aristocracia de sangue;
- Aristocracia rural;
- Aristocracia militar;
- Aristocracia menor;

## Background

### Antes da Repartição 

Através dos séculos, a aristocracia rural acumulou o poder político nas suas mãos, praticamente governando o país por trás dos panos com o Rei como marionete. Porém, por razão de sucessivas guerras civis, a aristocracia rural sofre graves perdas e acaba perdendo partes consideráveis da sua influência

Com o enfraquecimento da aristocracia rural, a aristocracia menor ascendeu politicamente, através do controle dos Conselhos Menores, embora o Rei X ainda detivesse a maior parte do poder político em suas próprias mãos 

Entretanto, o Rei X morreu e o seu sucessor não era nem metade do que ele era. Portanto, a figura do rei de Midland passou a ser controlado pela guarda real, que nem fantoches nas mãos de titereiros

O conflito pelo poder entre a guarda real e a aristocracia menor acabou enfraquecendo Midland ainda mais, ao ponto que isso incentivou a [[Partições|repartição]] de Midland entre [[World-Empire]], N1 e N2

### Anos Negros

[[Anos Negros]]
[[Traidores de Sangue]]

## Restauração 

A [[Casa Adrianus|Monarquia]] é [[Restauração|restaurada]] assim como a sua aristocracia pelo [[CWP]]

## Regime do Bosco

Durante o [[Regime do Bosco]], o [[Gabriel Bosco|Bosco]] perseguiu e enfrentou a aristocracia 

## Ditadura do Kirk

Durante a [[Ditadura do Kirk]], ocorreu a elitização de determinadas classes sociais em detrimento de outras