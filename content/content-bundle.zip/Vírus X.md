up:: [[Mapa do Mundo]]
tags:: #mundo 

# Vírus X

O Vírus X é o vírus por trás da [[Doença de Y]] e o responsável pela [[Pandemia do X]] 

[[]]

[[Órfãos de Y]]