up:: [[Mapa das Organizações]]
tags:: #organizações #antagonistas 

# Phantom Troupe

[[Samuel Darby]]