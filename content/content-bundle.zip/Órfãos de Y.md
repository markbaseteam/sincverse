up:: [[Pandemia do X]]
tags:: #mundo

# Órfãos de Y

Órfãos do Y é o nome dado para as crianças órfãs por causa da [[Pandemia do X]] 

[[Midland]]

## Índice 

[[Charles Babineaux]]
