up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Alain Baxter

[[Frente Rebelde]]

## Infobox 

**Nome**:: Alain Baxter
**Apelido**::
**Gênero**:: Homem (trans)
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::