up:: [[Governo de Midland]]
tags:: #organizações #antagonistas 

# Departamento de Defesa de Midland

O Departamento de Defesa é o órgão do [[Governo de Midland|governo de Midland]] responsável pela defesa da nação

[[Midland]]

## Estrutura

- [[Forças Armadas de Midland]]
	- [[Exército de Midland]]
		- [[Divisão de Operações Especiais de Midland]] 
	- [[Marinha de Midland]] 
	- [[Força Aérea de Midland]] 
	- [[Comando de Operações Conjuntas de Midland]]

## Afins

[[Academia Militar do Glass Lake]]