---
quickshare-date: 2023-07-21 19:47:40
quickshare-url: "https://noteshare.space/note/clkd697vz175601mwhvk39325#Pd8s6y5O2A77VBI0rZ50q/kzRNYZHqPrvPvHowMsNLk"
---
up:: [[Mapa do Mundo]]
tags:: #mundo 

# Regime do Bosco

Regime do Bosco é o nome que recebe o período em que o [[Gabriel Bosco]] governou [[Midland]] como primeiro-ministro

Depois do sucesso ao fim da [[Revolução das Romãs]], o [[NML]] consegue assumir por completo o poder em Midland

Embora parecesse o melhor momento para o NML, por causa de divergências ideológicas entre o Gabriel Bosco e o [[Adam Drake]] ocorre o [[Cisma da NML|racha da NML]]

Bosco defendia a posição de que o povo de Midland ainda não tinha a capacidade para o exercício pleno da democracia e portanto era obrigação do NML eleger internamente os representantes. Já o Adam defendia a posição de que o governo deveria ser democrático desde os seus primórdios,  pois se não, perderia sua legitimidade. Bosco convocou eleições entre os seus pares da NML para decidir qual proposta seguiria em frente. Por bem pouco, o Bosco conseguiu que sua proposta fosse aprovada. Entretanto, insatisfeito com o resultado, o Adam usando o seu poder e plataforma política tenta retirar o Bosco da jogada, mas não consegue. Adam é preso e mais tarde exilado. Após o exílio do Adam, a ala que o apoiava firmemente decide debandar da NML como protesto 

A [[Viola Spencer]] concordava com o programa do Regime do Bosco

## Regime

### Pontos positivos 

- Expansão das universidades;

### Pontos Negativos 

- Fundação da polícia secreta de Midland;

## Política 

Embora tivesse tentado manter relações diplomáticas e comerciais com outros países, por causa da [[CWP]], Midland ficou isolada politicamente falando, ficando cada vez mais alvo fácil para o [[World-Empire]]

## Fim

Depois da sua morte, o poder é disputado entre o [[Nicholas Kirk]] e o Z

O K consegue chegar ao poder através dum golpe de estado, dando início à sua [[Ditadura do Kirk|ditadura]]

## Veja mais 

+ [[Restauração]] 