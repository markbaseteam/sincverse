up:: [[Mapa dos Personagens]]
tags:: #personagens/terciários 

# Thomas Shelley

Shelley é o chefe da [[Unidade de Tortura e Interrogatório da Frente Rebelde]] da [[Frente Rebelde]] 

## Infobox 

**Nome**:: Thomas Shelley
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: BDSM
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: "Frente Rebelde", "Unidade de Tortura e Interrogatório"
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Diretor da Unidade de Tortura e Interrogatório 

## Personalidade

Shelley é cruel e sádico, sentindo prazer ao causar dor em outras pessoas. Em contraste com a sua crueldade e sadismo, ele gosta de conversar e contar piadas para quem ele está torturando, sendo bem-humorado e tendo senso de humor, o que por sua vez apenas o deixa mais bizarro e monstruoso. Com as outros pessoas, ele é cordial, cortês e educado. Assim como ele é sádico, o Shelley é masoquista, sentindo prazer apenas quando ele sente dor

## Background

Depois do Shelley ter passado semanas torturando brutalmente o Carl sem que o ele parasse de resistir, o Shelley acabou se apaixonando por ele

## Fluxo

Shelley é peritos em técnicas de cura, o que é muito útil para alguém como ele, embora que a sua técnica de acordo com ele mesmo seja pouco refinada e não consiga apagar cicatrizes ― não que ele queira apagar cicatrizes das torturas que ele pratica