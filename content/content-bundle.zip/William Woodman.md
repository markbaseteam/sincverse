up:: [[Mapa dos Personagens]]
tags:: #personagens/principais

# William Woodman

William “Liam” Woodman é o deuterogonista de Vengeance e o melhor amigo do Reid Dier

## Infobox 

**Nome**:: William Woodman
**Apelido**:: Liam
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background

O pai do Liam e o tio materno do Liam eram inimigos políticos do Estado e tiveram sua morte sancionada por políticos. Liam deseja se vingar desses políticos 

## Habilidades e poderes

Liam é perito em atirar facas

[[Alex Drake]]
[[Jolie Boyer]]
[[Emma Burgess]]
[[Frente Rebelde]]
[[SOC]]

