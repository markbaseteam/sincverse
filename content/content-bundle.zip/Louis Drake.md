up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários

# Louis Drake

[[Kieran Wood]]
[[Alex Drake]]
[[CJ Drake]]
[[Thomas Madison]]
[[Frente Rebelde]]

## Infobox 

**Nome**:: Louis Drake
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Gay
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::