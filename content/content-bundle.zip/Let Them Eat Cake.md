up:: [[Índice de Poderes]]
tags:: #poderes 
user:: 

# Let Them Eat Cake

LTEC permite a ele transformar coisas que não eram alimentos em alimentos. Ao mesmo tempo, ele pode extrair as propriedades daquele alimento ao comê-lo