---
quickshare-date: 2023-07-21 08:48:14
quickshare-url: "https://noteshare.space/note/clkcip69n051201mwnmsq6tle#dZyAPH0q0gdUGlVDyMNdUGKebS6j5PvzhzLdHBckaVQ"
---
up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Nicholas Kirk

Depois que [[Gabriel Bosco]] morre e o [[Regime do Bosco|seu regime]] acaba, o Nicholas disputa com o X pelo cargo de presidente da [[NML]]. Eventualmente, Kirk consegue ganhar via conspirações obscuras

Com a eleição do Kirk como presidente,  ele vai instaurar em [[Midland]] o que mais ficaria conhecido como [[Ditadura do Kirk]]

Kirk só é deposto depois que o [[World-Empire]] conquista militarmente Midland, momento em que o Kirk foge, mas é capturado pela [[Frente Rebelde]] e é julgado pelos seus crimes enquanto ditador

O [[We Stand]] da [[Viola Spencer]] seria o principal opositor político do Kirk durante a sua ditadura 

A ditadura do Kirk empregou o [[Amos Birdy]]