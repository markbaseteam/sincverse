up:: [[Governo de Midland]]
tags:: #organizações #antagonistas 

# CIB

O Escritório Central de Inteligência (CIB) é o departamento do [[Governo de Midland|governo]] de [[Midland]] que é responsável pela inteligência e contra-inteligência 


