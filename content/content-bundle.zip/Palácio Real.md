up:: [[Capital]]
tags:: #mundo

# Palácio Real

O Palácio Real era usado como residência oficial para a realeza de [[Midland]], hoje, o Palácio é a sede do governo ao mesmo tempo que serve como a residência do primeiro-ministro 

A construção do Palácio data de 2000 atrás e ao longo desses anos todos ele sofreu múltiplas reformas e ampliação. Cada novo rei que o deixasse ainda maior para satisfazer o seu ego

O palácio fica na [[Capital]]
