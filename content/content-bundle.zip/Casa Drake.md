up:: [[Mapa do Mundo]]
tags:: #mundo 

# Casa Drake

[[Midland]]

## Casa Drake no último século 

Já mortos: 

- [[Adam Drake]]
- [[Noel Drake]]

Ainda vivos, por enquanto: 

- [[Louis Drake]]
- [[CJ Drake]]
- [[Alex Drake]]