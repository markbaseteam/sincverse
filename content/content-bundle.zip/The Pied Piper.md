up:: [[Índice de Poderes]]
tags:: #poderes
user:: [[Raymond Carter]]

# The Pied Piper

The Pied Piper é o [[Poder|poder]] do

## Descrição

Ao tocar na sua flauta, ele consegue diferentes resultados 



