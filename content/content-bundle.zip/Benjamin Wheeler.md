up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Benjamin Wheeler

Benjamin Wheeler era o amigo do [[Noel Drake]], da [[Bailey]] e do [[Jude Tepes]]

## Infobox 

**Nome**:: Benjamin Wheeler
**Apelido**:: Benji
**Gênero**:: Homem
**Sexualidade**:: Bi
**Idade**::
**Nascimento**::
**Status**:: Falecido
**Afiliações-Anteriores**:: Frente Rebelde 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Biografia 

[[Frente Rebelde]]