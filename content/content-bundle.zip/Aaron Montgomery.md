---
categoria: personagem
---
up:: [[Mapa dos Personagens]]
tags:: #personagens/terciários

# Aaron Montgomery

Aaron Montgomery é o chefe do [[Departamento de Operações Militares da Frente Rebelde]] da [[Frente Rebelde]]

## Infobox 

**Nome**:: Aaron Montgomery 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Antigas**:: 
**Afiliações-Atuais**:: Frente Rebelde
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Chefe do Departamento de Operações Militares

## Aparência 

## Personalidade 

## Background

## Enredo

## Aptidões e poderes

## Batalhas e combates

## Trivia