up:: [[Mapa do Mundo]]
tags:: #mundo/lugares 

# Europa

[[Europa Oriental]] 

[[Midland]] 
[[World-Empire]]

