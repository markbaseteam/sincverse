up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários #antagonistas 

# Amos Keen

Amos Keen faz parte da [[Frente Rebelde]]

Amos Keen é o aliado e o oponente do [[Kieran Wood]] dentro da Frente Rebelde 

## Infobox 

**Nome**:: Amos Keen
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Conselheiro 

## Background 

[[Clube de Luta]]

## Enredo 

Amos manipula o [[Newt]] e a [[Facção Bergerista]] para conseguir o seu objetivo de entrar para o [[Conselho Geral da Frente Rebelde]] 


