up:: [[Mapa dos Personagens]]
tags:: #personagens/principais #antagonistas 

# Blaise Delacroix

Blaise era o melhor amigo do [[Alex Drake]] 

## Infobox

**Nome**:: Blaise Delacroix
**Apelido**:: Raven
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background

Blaise recebeu o mesmo treinamento que o Alex recebeu do [[Avô do Chisaki]]

Blaise entrou para o [[Exército de Midland]] de [[Midland]], embora tenha nascido no [[World-Empire]]

Blaise é o bisneto do [[Rei Tiberius I]] 

Blaise mais tarde viraria o capitão da [[13° Companhia]]