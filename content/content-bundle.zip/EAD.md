up:: [[Governo de Midland]]
tags:: #organizações #antagonistas 

# EAD

Departamento de Assuntos Extraordinários (ou simplesmente EAD) é o órgão do [[World-Empire]] que opera dentro de [[Midland]] 

Hoje, o Diretor do EAD é o [[Percy Le Goff]]

Embora o EAD em tese responda ao [[Governo de Midland|governo de Midland]], na prática isso não ocorre, já que o EAD responde ao [[Rei Tiberius I]]