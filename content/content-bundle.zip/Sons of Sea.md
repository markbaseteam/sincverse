up:: [[Submundo]]
tags:: #organizações #submundo

# Sons of Sea

Os Sons of Sea era o segundo maior sindicato criminoso de [[Harborside]] 

Os Sons of Sea vão fazer parte do [[Submundo]]

## Staff

- [[Edward Turner]]
