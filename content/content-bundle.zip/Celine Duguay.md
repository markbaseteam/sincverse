up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Celine Duguay

Celine é a mãe do [[Alex Drake]] e a amante do [[Noel Drake]]

## Infobox 

**Nome**:: Celine Duguay 
**Apelido**::
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Falecida
**Afiliações-Anteriores**:: Exército de Midland 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background 

Celine é a filha bastarda do [[Rei Tiberius I]] 

Celine nasceu em em [[World-Empire]]

Celine fazia parte do [[Exército Real de World-Empire]]