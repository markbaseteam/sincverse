up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# CJ Drake

Andrew  “CJ” Drake atualmente faz parte do [[Escudo]]

## Infobox 

**Nome**:: Drake
**Apelido**:: CJ 
**Gênero**:: Homem
**Sexualidade**:: Gay
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

# Aparência

CJ é esbelto e delgado, com compleição esguia, tez clara, rosto redondo, cabelos pretos e cacheados, olhos verdes, nariz arrebitado e cílios compridos

# Personalidade

CJ é avoado, tonto, atrapalhado e cabeça de vento

A memória do CJ é péssima. Ele só não esquece a cabeça por que ela está grudado ao seu corpo

Ele é gentil

Ele é simples e simplório

Ele não gosta de machucar pessoas ou animais

Ele tende a sempre acreditar e confiar nas pessoas

Ele é preguiçoso e indolente. O seu passatempo favorito é ficar na grama vendo as nuvens

CJ é simples e simplório. Ele é educado, gentil e simpático. Ele é honesto e sincero.

CJ é facilmente impressionável

CJ é ingênuo, tendendo a acreditar nas pessoas

CJ cumpre minuciosamente ordens que ele recebe dos seus superiores, embora ele prefire ficar deitado na grama vendo as nuvens

CJ gosta de conversar

CJ gosta de brincar 

Embora facilmente impressionável, ele não esboça nenhuma reação à ver pessoas morrendo, como se fosse nada demais

O moral e a ética do CJ são iguais ao moral e à ética do Gon

# Background

CJ não lembra quando entrou ou por que entrou para o Escudo

Embora não pareça, ele é a terceira pessoa mais poderoso do Escudo, somente abaixo do Madison e Arthur. De acordo com o Madison, se o CJ não fosse tão preguiçoso e trabalhasse mais duro, ele facilmente alcançaria o seu patamar assim com o de Arthur, talvez ultrapassando os dois

O talento que o CJ demonstra ter simplesmente eclipsa o talento de qualquer outra pessoa no Escudo

Para aprender algo, ele não precisa observar mais que duas vezes

# Trivia

CJ é primo do [[Alex Drake]] e do [[Louis Drake]] 