up:: [[Mapa dos Conceitos]]
tags:: #mundo/conceitos #magia

# Poder

[[Fluxo]]
[[Magia]]

## Definição 

Poder é o nome que é dado para a deformação da realidade causada pela expressão do usuário

Basicamente, um poder pode ser definido como a forma máxima de expressão da identidade do seu usuário no mundo

A definição dos poderes que pode ser dada é a seguinte: “um poder é a expressão da identidade do seu usuário no mundo, assim sendo, um poder é a extensão do “eu” do usuário”

A definição que pode ser dada para poderes é a seguinte: "Um poder é a expressão da identidade do usuário no mundo. Portanto, um poder é uma extensão do 'eu' do usuário.

## Subdivisões

[[Técnicas Inatas]]
[[Técnicas Hereditárias]]

next:: [[Índice de Poderes|Lista com todos poderes]]

