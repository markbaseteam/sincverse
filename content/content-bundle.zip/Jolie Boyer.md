up:: [[Mapa dos Personagens]]
tags:: #personagens/principais 
aliases:: Jolie Boyer

# Jolie Boyer

[[Alex Drake]] 
[[William Woodman]] 
[[Emma Burgess]] 
[[Frente Rebelde]]
[[SOC]] 
[[TJ Rutherford]]

## Infobox

**Nome**:: Marjorie Boyer
**Apelido**:: Jolie
**Gênero**:: Mulher
**Sexualidade**:: Bi
**Idade**:: 20 anos
**Nascimento**::
**Status**:: Viva
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::