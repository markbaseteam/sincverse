up:: [[Prisão de Segurança Máxima]]
tags:: #organizações #antagonistas 

# Serviço de Supervisão de Prisioneiros de Midland

O Serviço de Supervisão de Prisioneiros (PSS) é a organização responsável pela custódia, supervisão, segurança e regulamentação dos prisioneiros da [[Prisão de Segurança Máxima]] 

Os carcereiros do PSS são mais conhecidos como "Corvos"

## Enredo

[[Kieran Wood]] 
[[Paul Randall]]
[[Fuga da Prisão]]
