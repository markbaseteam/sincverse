up:: [[Índice de Poderes]]
tags:: #poderes 
user:: [[Louis Carpenter]]

# Model Building

Model Building é o [[Poder|poder]] do [[Louis Carpenter]]

## Descrição

Ao tocar em algo, Louis consegue o encolher para qualquer tamanho que ele quiser, desde que seja visível a olho nu 

## Análise 

### Eu 

COM:: 2
CON:: 5
MAG:: 3
PD:: 3
PO:: 3
PRA:: 3
UTI:: 3
VER:: 2

### Guilherme

com:: 0
con:: 0
mag:: 0
pd:: 0
po:: 0
pra:: 0
uti:: 0
ver:: 0

### Gráfico

```dataviewjs
const data = dv.current()
const chartData = {
	type: 'radar',
	data: {
		labels: ['COM','CON','MAG','PD','PO','PRA','UTI','VER'],
		datasets: [{
			label: 'Eu',
			data: [data.COM,data.CON, data.MAG,data.PD,data.PO,data.PRA,data.UTI,data.VER],
			fill: true,
		    backgroundColor: 'rgba(255, 0, 0, 0.25)',
		    borderColor: 'rgb(255, 99, 132)',
			pointBackgroundColor: 'rgb(255, 99, 132)',
		pointHoverBackgroundColor: '#fff',
		    pointHoverBorderColor: 'rgb(255, 99, 132)'}, {label: 'Guilherme',
    data: [data.com, data.con, data.mag, data.pd, data.po, data.pra, data.uti, data.ver],
    fill: true,
    backgroundColor: 'rgba(54, 162, 235, 0.2)',
    borderColor: 'rgb(54, 162, 235)',
    pointBackgroundColor: 'rgb(54, 162, 235)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgb(54, 162, 235)'
  }]},
	options: {
		scales: {
			r: {
				suggestedMin: 1,
				suggestedMax: 5
			}}
		}
};

window.renderChart(chartData, this.container);

```

## Veja mais 

[[Análise dos Poderes]] 