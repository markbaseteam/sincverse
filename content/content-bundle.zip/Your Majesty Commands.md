---
dg-publish: true
---
up:: [[Índice de Poderes]]
tags:: #poderes 
user:: [[Adrianus]]

# Your Majesty Commands

Your Majesty Commands é o [[Poder|poder]] do [[Adrianus]] 

## Descrição 

Através desse poder, o Adrianus consegue dar comandos para objetos inanimados, cadáveres e animais irracionais 

Primeiro, ele precisa visualizar o  comando em sua mente e depois anunciá-lo em voz clara. Nenhum dos comando pode ser demasiadamente longo, já que quão mais longos os comandos, maior o seu gasto de fluxo. Ele mede o comprimento em termos do número de verbos, em geral cada comando seu terá no máximo 3 verbos 

Qualquer comando que ele der, deve iniciar com "Your Majesty Commands You To", sem isso não é válido como comando 

O grau de complexidade dos comandos que cada elemento é suscetível depende do quão próximo está o elemento está dos seres humanos. Cadáveres vão estar suscetíveis a comandos mais complexos que cadeiras. Entretanto, o seu gasto de fluxo com cada comando é inversamente proporcional a quão próximo está dos seres humanos 

## Análise 

### Eu

COM:: 4
CON:: 5
MAG:: 4
PD:: 4
PO:: 2
PRA:: 4
UTI:: 4
VER:: 3

### Gráfico

## Veja mais 

[[Análise dos Poderes]]