up:: [[Mapa dos Personagens]]
tags:: #personagens/terciários  

# Agnes Crawford

Agnes Crawford é a [[Adjudicador|adjudicadora]] da [[Frente Rebelde]]

## Infobox 

**Nome**:: Agnes Crawford 
**Apelido**::
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Viva
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Adjudicadora 

## Aparência 

## Personalidade

Agnes é obcecada pela justiça

## Background

## Enredo

A princípio, Agnes suspeita que o [[Alex Drake]] e companhia são espiões do [[Governo de Midland|governo de Midland]]

Depois da [[Tragédia de Z]], Agnes suspeita que o [[Nathanaël Lamoureux]] havia traído a Frente Rebelde e o afasta momentaneamente do cargo de [[Presidente|presidente]]

Mais tarde, a Agnes envia a [[LEA]] para prender quem ela acreditava estar espionando a Frente Rebelde
