up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Kieran Wood

Kieran Wood é o amante de [[Louis Drake]]

Kieran já trabalhou para a [[Frente Rebelde]]

Kieran conspirou para assassinar o [[Noel Drake]], por que ele estava envolvido com a [[Celine Duguay]] e com coisa que não devia 

Kieran assassinou friamente a [[Bailey]]

Kieran manipulou e manipula: 

- [[Jude Tepes]]
- [[Louis Carpenter]]

Kieran quer algo com o [[Alex Drake]]

Kieran deseja transformar [[Midland]] num lugar melhor

Kieran mantém profundos laços com o [[Submundo]]

Kieran mantém acordos com: 

- [[Amos Keen]]
- Gente de dentro do [[Governo de Midland|governo de Midland]]

[[World-Empire]]

Usando da posição do Judah como Diretor do [[BCW]], Kieran consegue ter ainda mais influência 

## Infobox 

**Nome**:: Kieran Wood
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Ace
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: Frente Rebelde 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Enredo

Kieran manobra políticos do governo de Midland para conseguir que o [[Thomas Madison]] seja demitido da sua posição de Diretor do [[Escudo]], pois o Kieran sabia que quem iria assumir no lugar do Madison era o [[Arthur Weston]], que era com certeza menos preparado e equilibrado mentalmente que o Madison 

Kieran reconhece o [[Percy Le Goff]] como estando a sua altura em intelecto 

Kieran junto do [[Paul Randall]]  vão invadir a [[Prisão de Segurança Máxima]] e libertar numerosos criminosos perigosos

Kieran manipula a política dentro da Frente Rebelde e consegue retirar o [[Richard Stillwell]] do seu cargo

Kieran envia o Louis para assassinar a [[Lady Nagant]] 