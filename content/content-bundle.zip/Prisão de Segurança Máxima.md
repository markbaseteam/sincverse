up:: [[Governo de Midland]]
tags:: #mundo/lugares

# Prisão de Segurança Máxima

A Prisão de Segurança Máxima é a maior e mais importante prisão de [[Midland]], sendo o local para onde são enviados os criminosos capturados pelo [[Escudo]] e outras unidades do [[BCW]]

[[Governo de Midland]]

A prisão era guarnecida pelo [[Serviço de Supervisão de Prisioneiros de Midland]]

## Localização

## Organização 

A prisão é organizada em 4 blocos A, B, C e D, com cada bloco sendo isolados dos outros blocos. No centro fica a sala do Diretor e os únicos meios de entrar em cada bloco

## Enredo

[[Kieran Wood]] e o [[Paul Randall]] vão invadir a [[Prisão de Segurança Máxima]] e libertar numerosos criminosos

[[Fuga da Prisão]]

## Staff

- [[Diretor da Prisão]]

## Presos

- [[Adrianus]]
- [[Amos Birdy]] 