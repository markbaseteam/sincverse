up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Patrick Fisk

[[Frente Rebelde]] 
[[SOC]]

## Infobox 

**Nome**:: Patrick Fisk
**Apelido**::
**Gênero**::
**Sexualidade**::
**Idade**::
**Nascimento**::
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aptidões e poderes

[[Balloon]]
