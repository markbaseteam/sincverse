up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Daniel Hawbrough

Daniel Hawbrough é a personagem falsa do [[Ethan Nightshade]] 

[[Frente Rebelde]]
[[SOC]]

## Infobox

**Nome**:: Daniel Hawbrough 
**Apelido**::
**Gênero**:: Homem 
**Sexualidade**:: Gay
**Idade**::
**Nascimento**::
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::
