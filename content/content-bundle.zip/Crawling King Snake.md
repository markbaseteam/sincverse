up:: Índice de Poderes
tags:: #poderes
user:: [[Draco]] 

# Crawling King Snake

Crawling King Snake é o nome do [[Poder|poder]] do [[Draco]]

## Descrição

Draco é capaz de sumonar a Ophiucus, a sua serpente de estimação, baseada na *Gigantophis garstini*

## Análise 

### Eu

COM:: 4
CON:: 5
MAG:: 2
PD:: 1
PO:: 2
PRA:: 5
UTI:: 2
VER:: 1

## Veja mais 

[[Análise dos Poderes]]

