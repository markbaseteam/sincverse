up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 
aliases:: Blackjack

# Nathanaël Lamoureux

Nathanäel "Blackjack" Lamoureux é hoje o [[Presidente|presidente]] da [[Frente Rebelde]] 

## Infobox

**Nome**:: Nathanaël Lamoureux 
**Apelido**:: Blackjack 
**Gênero**:: Homem
**Sexualidade**:: Pan
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Presidente 

## Aparência 

Blackjack é alto e musculoso, com físico atlético, pele negra como carvão, cabelos traçados em dreadlocks, olhos castanhos escuros e barba feita. Ele é bonito 

## Background 

Blackjack era o aprendiz do [[Noel Drake]] 

Antes de namorar o Angel, o Blackjack só havia tido relacionamentos com mulheres 

## Enredo

Após a [[Tragédia de Z]], ele é afastado do seu cargo pela [[Adjudicador|adjudicadora]] [[Agnes Crawford]] sob suspeita de traição, mas eventualmente volta para a posição de presidente 

Depois de ser assassinado, Blackjack é sucedido pela [[Joanna Nettles]] 

## Relacionamentos

### Angel

Angel é o boy do Blackjack

## Trivia

- Blackjack é pan