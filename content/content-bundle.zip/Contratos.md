up:: [[Magia]]
tags:: #mundo/conceitos #magia 

# Contratos

[[Magia]]
[[Fluxo]]

- Condições 
- Requisitos de ativação 
- Restrições ou Limitações 
- Votos 

