up:: [[Mapa dos Conceitos]]
tags:: #conceitos 

# NP

Nível de Perigo (ou simplesmente NP) é o sistema desenvolvido e usado por Midland para categorizar o nível de perigo que qualquer criminoso que age dentro de Midland representa para o Estado

# Lista

## Nível S Superior[^note]

- ~~[[Adam Drake]]~~
- [[Louis Drake]]

## Nível S

- [[Amos Birdy]]
- [[Madeline J]]
- ~~[[Noel Drake]]~~
- [[Patchwork]]
- [[Viola Spencer]] (anteriormente)
- [[Zelda Creed]]

## Nível A

[[Aaron Montgomery]]
[[Akira Chisaki]]
[[Nathanaël Lamoureux]]
[[Paul Randall]]

## Nível A Inferior[^note]

## Nível B

^0827a8

[[AJ]]
[[Daniel Hawbrough]]

## Nível C

## Nível D

## Nível E

[^note]: classes criadas a posteriori ao próprio sistema, com o único objetivo de evitar a disparidade de poder que poderia ocorrer entre criminosos de mesmo nível

# Equivalências com os [[Graus]]

- Grau Especial = Nível S Superior e Nível S
- Grau Superior = Nível A e Nível A Inferior
- Grau Mediano = Nível B e Nível C
- Grau Inferior = Nível D e Nível E

## Fatores

Ferocidade
Número
Fertilidade
Destrutividade

Agressividade
Dificuldade de extermínio
Proezas de combate

Força
Nível de atividade
Influência
Hostilidade

Habilidade individual
Dano que pode causar
Influência
Incidentes de assassinato

Tempo de atuação
Feitos
Força
Informações
Nível de pedra no sapato para o governo

Poder Individual
Crimes
Conexões
Perigo relativo
Tempo na ativa
Experiência
