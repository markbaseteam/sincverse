---
aliases: Black Pearl
---
up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários #antagonistas 

# Madeline J

Madeline “Black Pearl” J é conhecida como a mulher mais bonita do mundo

## Infobox 

**Nome**:: Madeline J
**Apelido**:: Black Pearl
**Gênero**:: Mulher 
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::