up:: [[Mapa dos Personagens]]
tags:: #personagens/terciários  

# Olivia Wright

[[Frente Rebelde]]
[[Comando Setentrional da Frente Rebelde]]

## Infobox 

**Nome**:: Olivia Wright
**Apelido**:: Livvy
**Gênero**:: Mulher
**Sexualidade**:: Sapatão 
**Idade**::
**Nascimento**::
**Status**:: Viva
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Chefe do Comando Setentrional 