up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários #antagonistas 

# Alicia Huxley

Alicia Huxley 

## Infobox

**Nome**:: Alicia Huxley
**Apelido**:: Viúva Negra 
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**:: 21 anos
**Nascimento**:: 979
**Status**:: Viva
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aparência 

## Personalidade 

Como sempre havia alguém ao seu redor para controlar a sua vida, ela hoje é obcecado com controle

## Background 

Interesse romântico do [[Alex Drake]] 

## Poderes

[[The Dominance]]
