up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas  

# Newt

[[Facção Bergerista]]
[[Frente Rebelde]]
[[Amos Keen]]

## Infobox

**Nome**::
**Apelido**::
**Gênero**::
**Sexualidade**::
**Idade**::
**Nascimento**::
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: "Frente Rebelde", "Facção Bergerista"
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::