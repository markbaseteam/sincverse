up:: [[Mapa dos Antagonistas]]
tags:: personagens/antagonistas

# John Starkweather

John Starkweather faz parte do [[Escudo]]

John Starkweather é o filho adotivo de [[Thomas Starkweather]]

[[Alex Drake]] 

## Infobox 

**Nome**:: John Starkweather 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::