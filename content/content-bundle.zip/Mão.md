up:: [[Comissão]]
tags:: #organizações #antagonistas 

# Mão

A Mão é a elite da [[Comissão]]

A Mão é composta pelos [[Dedos]]

A Comissão usa a Mão como o seu dispositivo de coerção 

[[Submundo]] 

## Relação

- Dedão - 
- Indicador -
- Do Meio -
- Anelar - 
- Mindinho - 