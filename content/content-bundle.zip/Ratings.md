up:: [[Mapa dos Conceitos]]
tags:: #conceitos

# Ratings

Rating é o método desenvolvido e usado pelo governo de [[Midland]] para a categorização de quão úteis são os associados do [[Escudo]]

## Método

Cada fator que é importante para o Rating é medido de 0 a 5, para logo depois ser somado e ser multiplicado por 5, resultando num número de 0 a 100

Qualquer associado que tenha o Rating menor ou igual a 20 é automaticamente desligado do Escudo

## Lista

## 70


## Fatores

1. O número absoluto de criminosos presos;
2. O perigo que cada criminoso preso representava para o Estado;
3. O poder que cada criminoso preso tinha;