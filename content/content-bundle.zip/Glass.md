up:: [[Índice de Poderes]]
tags:: #poderes 
user:: [[Edmund Page]]

# Glass

## Descrição 

Caso seja golpeado, em vez de sofrer qualquer dano, o seu corpo é quebrado em múltiplos estilhaços. Logo, ele consegue evitar qualquer dano físico, mas não só isso, ele controla cada estilhaço proveniente da sua fragmentação, sendo capaz de reconstruir o seu corpo caso queira ou estilhaçar ele ainda mais

## Análise 

### Eu 

COM:: 1
CON:: 5
MAG:: 2
PD:: 3
PO:: 2
PRA:: 5 
UTI:: 4
VER:: 3

## Veja mais 

[[Análise dos Poderes]]