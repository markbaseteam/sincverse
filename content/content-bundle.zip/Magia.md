up:: [[Mapa dos Conceitos]]
tags:: #mundo/conceitos

# Magia

Magia é o sistema de magia de Vengeance 

Embora a maioria da população chame simplesmente de Magia, entre os "esclarecidos" existe a preferência pelo termo "Ciência Oculta"

## Propriedades 

- Conceitos centrais
	- [[Ritmo]]
		- [[Densidade]]
		- [[Fluxo]]
- Técnicas
	- [[Técnicas Comuns]]
		- [[Técnicas Básicas]]
		- [[Técnicas Avançadas]]
	- [[Poder|Técnicas Únicas]]
		- [[Técnicas Inatas]]
		- [[Técnicas Hereditárias]]
- Extensões 
	- [[Rituais]]
	- [[Contratos]]
	- [[Geister]]

## Definições 

> [!tip] Definição geral
> A Magia pode ser definida como a manifestação na realidade da consciência individual ou coletiva de organismos vivos

## Fluxograma

```plantuml

!define DARKRED
!includeurl https://raw.githubusercontent.com/Drakemor/RedDress-PlantUML/master/style.puml

object Magia

Magia : Sistema de poder de Vengeance 

class Ritmo {
Aura
Densidade de Aura
Fluxo de Aura
}

Magia --> Ritmo

```

