---
dg-publish: true
---
up:: [[Mapa das Organizações]]
tags:: #organizações 

# Frente Rebelde

A Frente Revolucionária para a Emancipação do Povo de Midland (RFEMP) é a organização revolucionária que luta pela emancipação de [[Midland]] frente o [[World-Empire]]

## Ideologia

Adam fundou junto do Edmund a Frente Rebelde com dissidentes do [[We Stand]] e [[NML]], organização de resistência popular fundada pela [[Viola Spencer]]

Hoje, a Frente Rebelde está “contaminada”, tendo alas da direita e centro

## Background

[[Adam Drake]] fundou a Frente Rebelde junto do [[Edmund Metcalfe]]

O objetivo da Frente Rebelde era reunir e organizar sob o mesmo guarda chuva as numerosas organizações populares de resistência existentes naquele contexto histórico 

Com o fim do [[We Stand]] ao longo da [[Ocupação Militar do World-Empire|Ocupação Militar]], a Frente Rebelde absorve a ala mais radical do movimento, que ainda pretendia continuar na luta. De igual modo, a [[Viola Spencer]] entra para a Frente Rebelde

## Estrutura

- [[Comitê Executivo da Frente Rebelde|Comitê Executivo]] 
- [[Suprema Corte da Frente Rebelde]]
- [[Conselho Geral da Frente Rebelde|Conselho Geral]] 
- [[Congresso da Frente Rebelde|Congresso]] 
- [[Convenção Geral da Frente Rebelde|Convenção Geral]]

### Estrutura militar

Proposta I:

1. Bloco - 5+ frentes, com cada bloco correspondendo a regiões geográficas do país;
2. Frente - 1+ colunas. Dentro de cada frente havia elementos de combate, apoio e infraestrutura. Consiste entre 50 a 500 combatentes;
3. Coluna - 2+ companhias
4. Companhia - 2+ guerrilhas. Consiste em média 50 combatentes;
5. Guerrilha - 2+ pelotões
6. Pelotões - mais ou menos 12 combatentes

Proposta II:

1. Comando
2. Brigada
3. Batalhão 
4. Unidade de Serviço Ativo

Proposta final:

#### Comando 

O [[Departamento de Operações Militares da Frente Rebelde]] da Frente Rebelde é subdividido em 6 comandos: 

- Comando Central 
- Comando Meridional 
- Comando Ocidental
- Comando Oriental 
- [[Comando Setentrional da Frente Rebelde]]
- [[SOC|Comando de Operações Especiais]]

Com cada comando sendo responsável única e exclusivamente pela sua própria região geográfica 


## Unidades

- [[LEA]]
- [[AT2S]]
- [[Unidade de Tortura e Interrogatório da Frente Rebelde]]
- [[Vanguarda]]

## Presidentes 

- [[Adam Drake]] 
- [[Noel Drake]]
- [[Nathanaël Lamoureux]]
- [[Joanna Nettles]]

## Referências 

- [[Presidente]]
- [[Comitê Executivo da Frente Rebelde]]
- [[Adjudicador]]
- [[Conselho Geral da Frente Rebelde]]

## Staff 

```dataview
LIST 
FROM #personagens 
WHERE contains(Afiliações-Atuais, "Frente Rebelde")
SORT file.mtime DESC
LIMIT 20
```