up:: [[Mapa do Mundo]]
tags:: #mundo/doenças 

# Mudblood

Mudblood é a doença que aflige o [[Jude Tepes]] e o resto da [[Casa Tepes]] 

As pessoas da Casa Tepes que estão com o Mudblood fora de controle são internadas nos [[Moonlit Gardens]]

## Trivialidades 

- O vampirismo associado a Casa Tepes é resultado dessa enfermidade