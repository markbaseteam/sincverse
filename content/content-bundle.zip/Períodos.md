---
dg-publish: true
---
up:: [[Mapa do Mundo]]
tags:: #mundo 

# Períodos

```timeline

+ ??? a 930 
+ Partição
+ Midland é repartida entre o World-Empire, N1 e N2

+ 930 a 935
+ Grande Guerra
+ A Grande Guerra acontece dentro de Midland

+ 935 a 940 (talvez 945)
+ Governo Provisório 
+ A CPW governa Midland sob a bandeira de Governo Provisório

+ 950 a ???
+ Regime do Bosco
+ Através do NML, Bosco consegue depor o Governo Provisório. Ele é eleito pelo NML como o Primeiro-Ministro

+ ??? a 970 
+ Ditadura do ???
+ Depois da morte do Bosco, ??? assume o poder através de golpes de Estado

+ 970
+ Guerra de Libertação de Midland
+ Midland é invadida pelos exércitos do World-Empire sob a bandeira de "libertação de Midland"

+ Depois de 970 a 975
+ Ocupação Militar
+ Ocupação Militar do World-Empire a Midland

+ 975 a ???
+ Protetorado
+ O governo provisório é obrigado a promulgar Midland como protetorado do World-Empire 
```
