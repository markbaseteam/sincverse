up:: [[Índice de Poderes]]
tags:: #poderes
user:: 

# Mold Breakdown

Ele permite que ele "quebre" qualquer objeto ou substância que toque, reduzindo-o imediatamente a seus componentes básicos: materiais inorgânicos como metal, pedra e plástico são reduzidos a suas moléculas componentes, enquanto matéria orgânica como madeira, carne e alguns tipos de tecido são quebrados em suas células constituintes. O nível de pureza molecular é deixado a seu critério, com ele podendo escolher se quer decompor a matéria orgânica em carbono puro. Ele também pode usar a habilidade em organismos vivos, reduzindo-os a seus componentes biológicos mais básicos.

