up:: [[Magia]]
tags:: #mundo/conceitos #magia 

# Técnicas Comuns

[[Magia]]

Ao contrário dos [[Poder|poderes]], as técnicas comuns são acessíveis a qualquer mago

[[Técnicas Básicas]] 
[[Técnicas Avançadas]]
