up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Draco

[[Crawling King Snake]]

[[Escudo]]

## Infobox 

**Nome**:: Draco
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background