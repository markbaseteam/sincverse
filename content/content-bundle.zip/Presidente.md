up:: [[Comitê Executivo da Frente Rebelde]]
tags:: #cargo 

# Presidente

A [[Frente Rebelde]] é governada pelo presidente junto do seu [[Comitê Executivo da Frente Rebelde]] 

## Descrição 

Embora em tese desempenhe o papel do poder executivo, o presidente é limitado pelo [[Adjudicador]] e [[Conselho Geral da Frente Rebelde]], tendo isso constituído assim pelo Adam Drake e [[Edmund Metcalfe]] para que evitar abusos de poder 

## Índex

- [[Adam Drake]]
- [[Noel Drake]]
- [[Nathanaël Lamoureux]]
- [[Joanna Nettles]]

## Trivia

- O termo presidente vem do inglês, "chairman"


