up:: [[BCW]]
tags:: #organizações #antagonistas 

# Escudo

A Seção 172 é a principal divisão do [[BCW]], servindo como o "FBI" de [[Midland]] 

A Seção 172 é o principal órgão de aplicação da lei 

Hoje, a Seção 172 é chefiada pelo Thomas Madison

## Missão 

- Aprisionamento se criminosos mais poderosos;
- Aprisionamento de criminosos ultra-perigosos;
- Aprisionamento de criminosos procurados em âmbito nacional;

## Estrutura

Os agentes do Escudo são organizados em: 

- Agentes de Campo 
- Agentes de Escritório 

## Relação dos agentes de campo

- [[Arthur Weston]]
- [[Cain Earnshaw]]
- [[Charles Babineaux]] 
- [[CJ Drake]]
- [[John Starkweather]]
- [[Monica Armstrong-Boothman]]
- [[Phil Cunningham]]
- [[Richard Spencer]]
- [[Samuel Darby]]
- [[Thomas Madison]]
- [[Thomas Heatherwick]]
- [[TJ Rutherford]]
