up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Louis Carpenter

[[Jude Tepes]]
[[Noel Drake]]
[[Alex Drake]]
[[Kieran Wood]]
[[AT2S]]
[[Frente Rebelde]]
[[Conselho Geral da Frente Rebelde]]

## Infobox 

**Nome**:: Louis Carpenter 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Gay
**Idade**::
**Nascimento**::
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aptidões e poderes 

[[Model Building]] 