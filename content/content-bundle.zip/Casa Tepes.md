up:: [[Mapa do Mundo]]
tags:: #mundo

# Casa Tepes
 
[[Jude Tepes]]
[[Mudblood]]
[[Moonlit Gardens]] 
[[Midland]]

A origem da Casa Tepes remonta a [[Europa Oriental]]

O [[Governo de Midland|governo de Midland]] usa a galera da Casa Tepes como agentes 