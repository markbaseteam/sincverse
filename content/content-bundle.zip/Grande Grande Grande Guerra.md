up:: [[Mapa do Mundo]]
tags:: #mundo #eventos 

# Grande Grande Grande Guerra

> [!tip] Citação sobre a Grande Grande Grande Guerra
> A Guerra para acabar com todas as Guerras

A Grande Grande Grande Guerra aconteceu quase em sua totalidade em [[Midland]]

A maior consequência da 3GW seria a criação da [[Comissão]] e [[CWP]]. Que eram lados diferentes da mesma moeda

[[Partições]]

[[World-Empire]] 
[[Adam Drake]]
[[Gabriel Bosco]] 
[[Rei Tiberius I]]
