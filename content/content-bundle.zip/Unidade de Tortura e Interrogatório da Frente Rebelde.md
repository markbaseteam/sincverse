up:: [[Departamento de Inteligência da Frente Rebelde]]
tags:: #organizações 

# Unidade de Tortura e Interrogatório da Frente Rebelde

A Unidade de Tortura e Interrogatório faz parte do [[Departamento de Inteligência da Frente Rebelde|Departamento de Inteligência]] da [[Frente Rebelde]] 

O Diretor hoje da Unidade de Tortura e Interrogatório é [[Thomas Shelley]]

## Vítimas Torturadas e Interrogadas 

- [[Carl Jager]]