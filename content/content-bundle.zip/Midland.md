---
dg-publish: true
---
up:: [[Mapa do Mundo]]
tags:: #mundo

# Midland

Midland é o país onde a maior parte da trama do Vengeance acontece

Como país, Midland está entre a lista de protetorados e colônias do [[World-Empire]] 

## História 

A história de Midland pode ser resumida numa palavra só: guerras, isso é, tanto guerras civis quanto guerras com outros países  

- [[Partições]]
	- [[Anos Negros]]
- [[Grande Grande Grande Guerra]]
- [[Restauração]]
- [[Revolução das Romãs]]
- [[Regime do Bosco]]
- [[Ditadura do Kirk]]
- [[Ocupação Militar do World-Empire]]
- [[Protetorado]]

## Geografia 

## Demografia

## Governo e política 

Por estar numa condição de protetorado, o [[Governo de Midland]] é submisso ao governo do World-Empire 

## Divisões internas 

### Cidades

- [[Capital]] 
- [[Harborside]] 

## Economia 

- Extração de [[Magnite]] e outros minérios 

## Outros 

- [[Aristocracia]]
	- [[Casa Spencer]]
	- [[Casa Jager]]

- [[Frente Rebelde]]
- [[MRM]]
- [[Phantom Troupe]]
- [[The Stench]]

## Trivia 

- Etimologia 