up:: [[Midland]]
tags:: #mundo

# Capital

A Capital de [[Midland]]

## Lugares

[[Palácio Real]]