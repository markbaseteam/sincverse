up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários #antagonistas 

# Arthur Weston

Arthur era o Diretor do [[Escudo]] antes da entrada do [[Thomas Madison]]

Ele é o irmão mais velho do [[Daniel Weston]] e [[Eli Weston]]

## Infobox 

**Nome**:: Arthur Weston
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Gay
**Idade**::
**Nascimento**::
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: Diretor
**Ocupações-Atuais**:: 

## Personalidade 

Embora seja gay, ele não consegue aceitar o fato que é gay

Ele odeia mulheres no geral, por que além de trabalhar num bordel, a sua mãe o abandonou 

O seu relacionamento com os seus irmãos é tóxico por que o seu pai sempre dizia que a sua obrigação cuidar dos seus irmãos e quando ele não cuidava o seu pai batia nele

O Arthur é fascinado por produtos químicos 

## Background
B
Depois que ele perde o posto de Diretor para o Thomas, ele sai em férias permanentes. Quando o Thomas é mais tarde retirado do cargo, ele volta

## Combates 

- Arthur Weston vs. **[[Patchwork]]**