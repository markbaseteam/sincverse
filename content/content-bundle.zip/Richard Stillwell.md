up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários #antagonistas 

# Richard Stillwell

Richard Stillwell é o chefe do [[Conselho Geral da Frente Rebelde]] da [[Frente Rebelde]]. Ele é o cara que manda na [[AT2S]].

Como ele havia tido problemas com o [[Noel Drake]], ele não confia no Alex Drake e envia o [[Louis Carpenter]] para o assassinar 

## Infobox

**Nome**:: Richard Stillwell
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: 
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Conselheiro 