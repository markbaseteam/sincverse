up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas 

# Thomas Heatherwick

Thomas Heatherwick faz parte do [[Escudo]]

## Infobox 

**Nome**:: Thomas Heatherwick 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aptidões e poderes

[[Battle Waltz]]

## Combates

- **Thomas Heatherwick** vs. [[Alex Drake]]