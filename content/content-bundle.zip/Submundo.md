up:: [[Mapa do Mundo]]
tags:: #mundo

# Submundo

O Submundo (do inglês Underground) pode ser definido como a rede de sujeitos ou organizações que estão envolvidas em atividades criminosas, como por exemplo, crime organizado, tráfico de drogas, contrabando, lavagem de dinheiro e outros empreendimentos ilegais

O Submundo é governado pela [[Comissão]] 
A Comissão usa a sua própria unidade de elite privada, cujo nome é a [[Mão]] 

## Sujeitos

## Criminosos 

- [[Kieran Wood]]

### Fornecedores de serviços

- [[Os Trigêmeos]]
- [[The Bogeyman]] 
- [[The Cook]] 

## Organizações

### Fornecedores de serviços 

- [[Clube de Luta]]
- [[The Body Shop]]
- [[Casa de Leilões]]

### Sindicatos criminosos

- [[Sons of Sea]]