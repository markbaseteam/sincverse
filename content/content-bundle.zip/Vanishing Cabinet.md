up:: [[Índice de Poderes]]
tags:: #poderes
user:: [[Phil Cunningham]] 

# Vanishing Cabinet

Vanishing Cabinet é o nome que o [[Phil Cunningham]] deu para o seu [[Poder|poder]] 

## Descrição

Para que possa usar seus poderes, Phil precisa cumprir 3 etapas: a fonte, a ação e a despensa: 

A despensa é o local para onde o objeto será transportado. Em geral, o Phil usa sempre o mesmo armário

A ação é o ato que precisará ser realizado para que o objeto seja transportado de onde está para a despensa

A fonte é a instância que serve como meio de transferência através da ação para a despensa

Ele primeiro precisa fixar a despensa, para depois fixar a ação e a fonte, nessa ordem específica

## Análise 

### Eu

COM:: 1
CON:: 5
MAG:: 2
PD:: 3
PO:: 1
PRA:: 5
UTI:: 3
VER:: 4

## Veja mais 

[[Análise dos Poderes]]