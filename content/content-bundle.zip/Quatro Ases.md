up:: [[BCW]]
tags:: #organizações #antagonistas 

# Quatro Ases

A Seção 666 é o nome da unidade designada para o cumprimento de missões de perigo e risco excepcionais. A Seção 666 informalmente é mais conhecida como os Quatro Ases

# Staff

- Espadas ->
- Copas -> [[Edward Turner]]
- Paus
- Ouros

# Veja mais

[[BCW]]