up:: [[Submundo]]
tags: #submundo/assassinos

# Os Trigêmeos

Os Trigêmeos são assassinos de aluguel do [[Submundo]]

