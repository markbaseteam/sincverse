up:: [[Governo de Midland]]
tags:: #mundo/conceitos 

# Programa de Recrutamento de Órfãos

O Programa de Recrutamento de Órfãos é o programa criado e usado pelo governo de [[Midland]] para transformar órfãos em agentes leais do [[Governo de Midland|regime]]

[[BCW]]

## Ex-participantes 

- [[Paul Randall]]
- [[Charles Babineaux]] 
