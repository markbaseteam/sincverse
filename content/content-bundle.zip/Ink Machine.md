up:: [[Índice de Poderes]]
tags:: #poderes 
user::

# Ink Machine

## Descrição

Em breves palavras, quem faz uso desse poder é capaz de manipular tinta para diferentes fins 

## Técnicas

### Moving Pictures

A pessoa que faz uso dessa técnica é capaz de animar e controlar desenhos e pinturas a base de tinta. Entretanto, como são feitos de tinta, praticamente qualquer golpe é capaz de dispersá-los
