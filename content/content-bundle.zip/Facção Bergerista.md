up:: [[Frente Rebelde]]
tags:: #organizações #antagonistas 

# Facção Bergerista

Facção reacionária dentro da [[Frente Rebelde]]

[[René Berger]] é o fundador dessa Facção 

[[Newt]]

[[Gabriel Bosco]] 
[[Regime do Bosco]]

[[Amos Keen]]
