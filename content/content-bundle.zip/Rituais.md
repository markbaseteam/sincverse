up:: [[Magia]]
tags:: #mundo/conceitos 

# Rituais

Rituais são práticas realizadas por magos com o objetivo de 

[[Magia]]