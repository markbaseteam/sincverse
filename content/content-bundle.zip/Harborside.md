up:: [[Midland]]
tags:: #mundo 

# Harborside

Harborside é a maior cidade de [[Midland]]

## Organizações 

[[Sons of Sea]]