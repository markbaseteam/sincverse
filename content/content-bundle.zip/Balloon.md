up:: [[Índice de Poderes]]
user:: [[Patrick Fisk]]
tags:: #poderes

# Balloon

Balloon é o [[Poder|poder]] do [[Patrick Fisk]] 

## Descrição 

Ao respirar fundo, ele é capaz de inflar o seu corpo, que nem baiacus, elevando a sua força física e durabilidade. Entretanto, ele precisa manter a sua respiração presa caso queira continuar nesse modo

## Análise 

### Eu 

COM:: 2
CON:: 5 
MAG:: 2
PD:: 2
PO:: 2
PRA:: 3
UTI:: 3
VER:: 1

### Guilherme

### Gráfico

```dataviewjs
const data = dv.current()
const chartData = {
	type: 'radar',
	data: {
		labels: ['COM','CON','MAG','PD','PO','PRA','UTI','VER'],
		datasets: [{
			label: 'Eu',
			data: [data.COM,data.CON, data.MAG,data.PD,data.PO,data.PRA,data.UTI,data.VER],
			fill: true,
		    backgroundColor: 'rgba(255, 0, 0, 0.25)',
		    borderColor: 'rgb(255, 99, 132)',
		    pointBackgroundColor: 'rgb(255, 99, 132)',
		    pointHoverBackgroundColor: '#fff',
		    pointHoverBorderColor: 'rgb(255, 99, 132)'}]},
	options: {
		scales: {
			r: {
				suggestedMin: 0,
				suggestedMax: 5
			}}
		}
}

window.renderChart(chartData, this.container);

```

## Veja mais 

[[Análise dos Poderes]]