up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários
# Patchwork

Patchwork faz parte da [[Frente Rebelde]]

Patchwork é o comandante do [[SOC]]

## Infobox 

**Nome**::
**Apelido**:: Patchwork
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Combates

- **Patchwork** vs. [[Arthur Weston]] 
- Patchwork vs. **[[Amos Birdy]]**

## Trivia

- O apelido do Patchwork vem da sua ancestralidade diversa 