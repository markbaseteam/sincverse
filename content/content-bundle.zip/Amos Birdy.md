up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Amos Birdy 

Amos Birdy está atualmente preso 

## Infobox 

**Nome**:: Amos Birdy
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background

O seu pai fazia parte do [[NML]] e como pode ser naturalmente constatado, o pai do Amos amava a sua pátria e ensinou para o seu filho que ele deveria amar e servir ao seu país acima de tudo e todos

Com apenas 16 anos o Amos entrou para as [[Forças Armadas de Midland]] de [[Midland]], mostrando ao que veio com rapidez, entrando mais tarde para a [[Divisão de Operações Especiais de Midland]]

Eventualmente, o Amos virou o carrasco oficial da [[Ditadura do Kirk]], sendo o responsável por executar os opositores do governo. Num primeiro momento, o Amos acreditava piamente que as ações eram certas, pois ele estava apenas limpando o lixo que queria o mal para a sua tão amada pátria, mas ele logo percebeu que estava executando qualquer pessoa que se opusesse ao regime, isso é, de igual modo ele estava executando pessoas inocentes

Mais tarde, o Amos seria consagrado como herói nacional pelo próprio [[Nicholas Kirk]]

Cansado de assassinar gente inocente, o Amos Birdy decidiu que já bastava e pediu demissão, mas o seu superior não quis aceitar a sua demissão, obrigando o Amos a simplesmente ir embora. Entretanto, como o Amos sabia demais, o seu antigo superior enviou os seus colegas para o executar. Sem escolha, o Amos acaba assassinando os seus antigo colegas. Como o seu antigo superior continuava enviando assassinos para o matar, o Amos vai atrás dele e o mata para acabar com a sua perseguição 

Mais tarde, quando o [[World-Empire]] declarou guerra a Ditadura do K, o Amos decidiu ajudar o exército de World-Empire, pois realmente acreditava que o objetivo do World-Empire era ajudar a população de Midland, ledo engano

Mais tarde, com a instituição do [[Governo de Midland]], o Amos estava mais disposto a ajudar. Entretanto, ele acabou sendo outra vez cooptado pelo sistema e acabou novamente tendo suas capacidades usadas para assassinar oponentes políticos e afins para o governo. Quando menos percebeu estava matando novamente gente inocente. Ao perceber isso, ele quebrou e simplesmente assassinou a sangue frio todo mundo que compunha o governo no que seria encoberto pelo governo seguinte e ficaria conhecido como a [[Tragédia de M]]

Amos acabou sendo preso na [[Prisão de Segurança Máxima]]


