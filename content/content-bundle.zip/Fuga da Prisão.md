up:: [[Índice de Eventos]]
tags:: #eventos 

# Fuga da Prisão

A fuga em massa da [[Prisão de Segurança Máxima]] ocorrida em razão da infiltração do [[Kieran Wood]] e [[Paul Randall]] 

