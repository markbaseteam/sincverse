up:: [[BCW]]
tags:: #organizações #antagonistas 


# Spear

A Seção 646 é apelidada de Spear, por causa do seu aspecto mais ofensivo, em contraste com o [[Escudo]]

[[BCW]] e [[Midland]] 

## Background 

A Spear nasce depois da [[Fuga da Prisão|fuga em massa]] da [[Prisão de Segurança Máxima]], ocasionado pelo [[Kieran Wood]] e [[Paul Randall]]

É responsabilidade da Sword recapturar cada criminoso que fugiu da Prisão 

A Spear é a organização que o [[Governo de Midland|governo de Midland]] funda para enfrentar e subjugar os adversários do Estado 

[[Percy Le Goff]] está por trás da fundação da Spear
