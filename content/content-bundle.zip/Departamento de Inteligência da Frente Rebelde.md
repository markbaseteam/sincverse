up:: [[Comitê Executivo da Frente Rebelde]]
tags:: #organizações 

# Departamento de Inteligência da Frente Rebelde

O Departamento de Inteligência é a organização dentro da [[Frente Rebelde]]  responsável pela inteligência e contra-inteligência 

O Departamento de Inteligência é parte do [[Comitê Executivo da Frente Rebelde]], com o seu Diretor sendo indicado pelo [[Presidente]] e sendo efetivado pelo [[Conselho Geral da Frente Rebelde]]

## Unidades


- [[Unidade de Tortura e Interrogatório da Frente Rebelde]]
- Unidade de Contra-inteligência 