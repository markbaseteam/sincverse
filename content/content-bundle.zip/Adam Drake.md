---
dg-publish: true
---
up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Adam Drake

Adam fundou a [[Frente Rebelde]] 

[[We Stand]] 
[[Rei Tiberius I]]
[[Noel Drake]]
[[Alex Drake]]
[[Regime do Bosco]]
[[Ditadura do Kirk]]
[[Revolução das Romãs]] 
[[CWP]]
[[Presidente]]

## Infobox 

**Nome**:: Adam Drake
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Falecido
**Afiliações-Anteriores**:: "NML", "We Stand", "Frente Rebelde"
**Afiliações-Atuais**::
**Ocupações-Antigas**:: Presidente 
**Ocupações-Atuais**::

## Biografia

Adam Drake nasceu numa [[Casa Drake|casa abastada]] que residia na parte de [[Midland]] que pertencia a [[World-Empire]]

Desde sempre, o Adam estudou nas melhores e mais caras escolas de Midland ao mesmo tempo que o pai do Adam contratou numerosos tutores particulares para o Adam, para que ele tivesse aptidão em tudo o que fizesse 

Mais tarde, dando seguimento a sua educação formal, ele acabou entrando na [[Universidade de World-Empire|universidade]] mais prestigiada de World-Empire, indo estudar Ciências Naturais, ainda que o seu pai quisesse que ele cursasse Direito

Entretanto, com o estopim da [[Grande Grande Grande Guerra|Grande Grande Grande Guerra]], ele voltou para Midland e entrou para o [[Exército Real de World-Empire]] 

Em razão das suas proezas em combate assim como a influência do seu sobrenome, ele recebeu o cargo de Capitão

Mais tarde, enquanto estava em batalha, o Adam teria a sua vida salva pelo soldado raso [[Gabriel Bosco]]. À época, Bosco tinha somente 18 anos e já estava vivenciando os horrores da guerra 

Adam virou amigo do Gabriel e mesmo com o fim da guerra continuou mantendo correspondência com o Gabriel. Adam voltou para a universidade para terminar o seu curso de Ciências Naturais, enquanto que o Gabriel acabou indo trabalhar no jornal [[Vontade Popular]], que entre outra coisas denunciava os crimes da [[Restauração|Monarquia]]

Depois de ter terminado o seu curso, o Adam engatou já o seu mestrado e doutorado

Logo depois de ter voltado para a universidade, Adam conheceu a [[Viola Spencer]]. À época, Viola cursava Filosofia e estava sendo orientada pelo professor Emmanuel, que seria o seu futuro amante e futuro conselheiro do Bosco ao longo do seu Regime 

Enquanto editor do Vontade Popular, o Gabriel era profundamente crítico a Monarquia, por isso que o Governo decidiu fechar o jornal, mas o Gabriel continuou editando o jornal por debaixo dos panos. Mas, em razão disso tudo, o Gabriel decidiu ser mais ativo, participando, organizando e encabeçando protestos contra a Monarquia, incluindo o protesto que desembocaria nas [[Revoltas de Julho]]

Nesse protesto em específico, a [[Polícia Real]] à serviço do [[Rei de Midland]] havia sido instruida a dispersar a multidão, caso ela tentasse seguir em direção ao [[Palácio Real]], mas quando a Polícia Real tentou dispersar os manifestantes com truculência, houve o revide na mesma moeda, fazendo com que a Polícia Real investisse contra os manifestantes com violência excessiva, que ao invés de recuar ou fugir como era o usual, decidiu pagar na mesma moeda e revidar com igual violência, transformando a [[Praça da Águia Vermelha]] num campo de batalha. A violência rapidamente escalou para o resto da [[Capital]], transformando a cidade num verdadeiro cenário de guerra urbana, com barricadas espalhadas pelas ruas e assim por diante. Gabriel reuniu e organizou revoltosos para tentar capturar o Palácio Real e depor o Rei, mas acabou fracassando, embora a vitória do Gabriel parecesse inevitável, já que a Polícia Real parecia estar perdendo o controle da situação na capital. Quando enfim chegou os reforços solicitados pelo Rei e o que aconteceria em seguida seria o encarceramento e a execução em massa de milhares de revoltosos, incluindo as suas principais lideranças, aliado da decretação de toques de recolher para todos residentes da capital. Vendo isso, Gabriel e o resto das lideranças da revolta decidiu fugir para o interior do país 

Lá no interior de Midland, o Gabriel fundou o seu primeiro movimento de resistência popular, mas por causa da falta de organização, patrocínio e recursos, o Gabriel acabou sendo preso e o movimento desmantelado

Ao saber das Revoltas de Julho, o Adam voltou para Midland e descobriu que o Gabriel havia sido preso. Como não era besta nem nada, o Adam usou da sua influência para libertar o Gabriel da prisão e retirar quaisquer acusações contra ele 

Por saber das condições de vida dos camponeses, o Gabriel sabia que o interior do país era chave caso ele tivesse a pretensão de fundar qualquer movimento de resistência popular. Logo, ele decidiu que deveria iniciar o seu trabalho de base no interior de Midland. Adam o acompanhou tanto na sua ida quanto no seu trabalho de base pelo interior de Midland.

A partir disso, Gabriel fundou o [[NML]] junto do Adam no interior de Midland

Como o Gabriel conhecia de perto a realidade daquelas pessoas assim como sabia discursar para multidões, o NML registrou rápido adesão entre os camponeses, algo que surpreendeu ambos Gabriel e Adam

Gabriel escreveu o programa político do NML enquanto que o Adam organizou a estrutura militar do NML. Como o Adam fazia parte da aristocracia, ele financiou o NML tanto com dinheiro quanto com insumos 