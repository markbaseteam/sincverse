up:: [[Mapa do Mundo]]
tags:: #mundo 

# Traidores de Sangue

Termo cunhado pelo [[Gabriel Bosco]] para  fazer referência a [[Aristocracia|aristocracia]] que apoiou a dominação de [[World-Empire]], N1 e N2 a [[Midland]] 

[[Anos Negros]] 

F 