---
quickshare-date: 2023-07-21 10:03:06
quickshare-url: https://noteshare.space/note/clkcldgke072301mwxffu4kcp#Z9ejTKGOQpiG4lar8fAIBei6Zi3qYrO/9QkKazEAgVQ
COM: 4
PD: 4
PO: 3
PRA: 4
UTI: 4
VER: 4
CON: 3
MAG: 3
dg-publish: true
---
up:: [[Índice de Poderes]]
tags:: #poderes
user:: [[TJ Rutherford]] 

# Toy Story

Toy Story é nome do [[Poder|poder]] do [[TJ Rutherford]]

# Descrição

TJ desenvolveu o poder de dar vida a objetos inanimados

Do seu ponto de vista, para que algo possa ser considerado vivo, ele precisa cumprir certas condições. Logo, qualquer objeto animado pelo TJ vai ser capaz de: 

- “andar”, mesmo sem ter pernas, pés ou algo análogo; 
- "falar", mesmo sem ter boca e aparelho fonológico;
- “perceber” o mundo através dos sentidos, mesmo sem ter órgãos sensoriais;
- “raciocinar”, mesmo sem ter cérebro;

Consequentemente, caso o objeto não tenha traços faciais próprios, ele acaba os desenvolvendo quando animado pelo TJ

Todo objeto animado deve ter o seu próprio nome próprio, que é dado pelo TJ no momento do seu "nascimento"

TJ não pode controlar os objetos animados, embora cada objeto animado tenda a acreditar que o TJ é seu amigo

Além disso, a personalidade de cada objeto animado é derivada da personalidade do próprio TJ

Embora nunca tenha testado, ele acredita ser capaz de animar cadáveres 

## Objetos Animados

- Sir Bucket Helm (armadura medieval completa);
- Lord Griffin (escultura de grifo, inspirado em o Aprendiz de Feiticeiro);
- Mrs. ??? Keep (casa em que o TJ vive, inspirado em a Casa Monstro);
- Mr. Broad Cloak (o manto que o TJ usa, inspirado em Dr. Estranho e One Piece ― produzido através do entrelaçamento tanto de placas de metal quanto de argolas de metal);
- Miss Bath Water (água da banheira da suíte do TJ, inspirado em One Punch Man);
- Revólver e Balas;
- Par de Cimitarras;

## Gráfico 

```dataviewjs
const data = dv.current()
const chartData = {
	type: 'radar',
	data: {
		labels: ['COM','CON','MAG','PD','PO','PRA','UTI','VER'],
		datasets: [{
			label: 'Eu',
			data: [data.COM,data.CON, data.MAG,data.PD,data.PO,data.PRA,data.UTI,data.VER],
			fill: true,
		    backgroundColor: 'rgba(255, 0, 0, 0.25)',
		    borderColor: 'rgb(255, 99, 132)',
		    pointBackgroundColor: 'rgb(255, 99, 132)',
		    pointHoverBackgroundColor: '#fff',
		    pointHoverBorderColor: 'rgb(255, 99, 132)'}]},
	options: {
		scales: {
			r: {
				suggestedMin: 1,
				suggestedMax: 5
			}}
		}
}

window.renderChart(chartData, this.container);

```

