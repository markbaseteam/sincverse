up:: [[Mapa das Organizações]] 
tags:: #organizações #antagonistas 

# CWP

A CWP (Comissão para a Paz Mundial) é a comissão que nasceu após a [[Grande Grande Grande Guerra]]

Emboea pareça contraditório com o seu nome, a CWP não é tão pacífica assim não

A CWP deseja o controle sobre [[Midland]], pois ?

A CWP deseja retirar o [[World-Empire]] da jogada para que possa efetivamente dominar Midland

## Desdobramento 

A CWP está intimamente ligada com a [[Comissão]], já que são faces diferentes da mesma moeda.

A CWP deseja trazer ordem e estabilidade para o Mundo enquanto que a Comissão deseja trazer ordem e estabilidade para o [[Submundo]] 

## Agentes

[[Ethan Nightshade]]