---
dg-publish: true
---
up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Gabriel Bosco

Antigo amigo do [[Adam Drake]] 

[[Regime do Bosco]]

[[NML]]

[[Anos Negros]] 
[[Restauração]] 
[[Revolução das Romãs]]

[[Nicholas Kirk]]
[[Ditadura do Kirk]]

[[Viola Spencer]]

[[CWP]]

## Infobox

**Nome**:: Gabriel Bosco
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Falecido
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: Presidente 
**Ocupações-Atuais**::

## Biografia

Gabriel nasceu e viveu a maior parte da sua infância e adolescência na [[Partição de World-Empire|partição]] de [[Midland]] que pertencia a [[World-Empire]]. Os seus pais eram mineradores paupérrimos e super-explorados pela empresa X 

Embora nenhum dos seus pais tivesse sido propriamente alfabetizado, o Gabriel acabou sendo alfabetizado numa iniciativa do sindicato dos mineradores da empresa X 

Por ter crescido nesse meio, Gabriel entendia a condição de vida dos trabalhadores em detrimento da nobreza 

O jornal [[Vontade Popular]] era a principal fonte de informação que a classe dos trabalhos urbanos tinha. Por conta disso, como jornalista e mais tarde editor-chefe do Vontade Popular, o Gabriel estava em contato constante com os trabalhadores, fazendo com que ele estivesse em contato direto com as demandas destes

Nesse protesto em espcífico, a [[Polícia Real]] à serviço do [[Rei de Midland]] havia sido instruida a dispersar a multidão, caso ela tentasse seguir em direção ao [[Palácio Real]], mas quando a Polícia Real tentou dispersar os manifestantes com truculência, houve o revide na mesma moeda, fazendo com que a Polícia Real investisse contra os manifestantes com violência excessiva, que ao invés de recuar ou fugir como era o usual, decidiu pagar na mesma moeda e revidar com igual violência, transformando a [[Praça da Águia Vermelha]] num campo de batalha. A violência rapidamente escalou para o resto da [[Capital]], transformando a cidade num verdadeiro cenário de guerra urbana, com barricadas espalhadas pelas ruas e assim por diante. Gabriel reuniu e organizou revoltosos para tentar capturar o Palácio Real e depor o Rei, mas acabou fracassando, embora a vitória do Gabriel parecesse inevitável, já que a Polícia Real parecia estar perdendo o controle da situação na capital. Quando enfim chegou os reforços solicitados pelo Rei e o que aconteceria em seguida seria o encarceramento e a execução em massa de milhares de revoltosos, incluindo as suas principais lideranças, aliado da decretação de toques de recolher para todos residentes da capital. Vendo isso, Gabriel e o resto das lideranças da revolta decidiu fugir para o interior do país 

## Obras 

Embora não considerasse a si mesmo como comunista, o Gabriel Bosco era de esquerda radical 

- Ensaios gerais sobre a conjuntura política, social e histórica da Grande Grande Grande Guerra 
- Revoltas de Julho: a verdadeira história por trás do mito 
- A Revolução das Romãs: Visão geral sobre a revolução 
- Dualidade campo e cidade 
- Reflexões críticas sobre as guerras e a paz 