up:: [[Midland]]
tags:: #mundo/lugares

# Glass Lake

Glass Lake fica [[Midland]] 

[[Academia Militar do Glass Lake]] 