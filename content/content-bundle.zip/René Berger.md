up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# René Berger

René Berger é o fundador da [[Facção Bergerista]]

René faz parte da [[Frente Rebelde]]

**Nome**:: René Berger
**Apelido**:: 
**Gênero**:: Homem 
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Falecido
**Afiliações-Anteriores**:: "Frente Rebelde", "Facção Bergerista"
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::