up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Zelda Creed

Zelda Creed faz parte da [[Frente Rebelde]] 
Zelda era rival do [[Louis Drake]] 

Zelda capitaneava a [[Vanguarda]]

Zelda enfrenta o [[Jude Tepes]] 

## Infobox 

**Nome**:: Zelda Creed
**Apelido**::
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Viva
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: "Frente Rebelde", "Vanguarda"
**Ocupações-Antigas**:: 
**Ocupações-Atuais**:: Chefe da Vanguarda