up:: [[Mapa do Mundo]]
tags:: #mundo

# Trajetória

## Aristocracia e Monarquia

A [[Aristocracia]] em [[Midland]]  remonta aos antigos chefes dos clãs guerreiros, cuja zona de ocupação era Midland inteira

Depois de anos guerreando entre si, o Grande Rei unificou todos os clãs através do poder militar mesmo

Depois de séculos de estagnação política, a situação em Midland favoreceu a transformação dos clãs guerreiros no que seria a aristocracia rural de Midland, que por sua vez já não lembrava em nada os antigos clãs guerreiros

Assim como outras aristocracias pelo mundo, as aristocracias de Midland eram chauvinistas, entrando constantemente em conflitos com o Rei pelo poder, o que por sua vez enfraquecia Midland, deixando-a suscetível a invasões de outras nações

## Partilha

Midland é invadida pelos exércitos das nações de [[World-Empire]], N1 e N2. Mesmo que estivesse enfrentando 3 inimigos ao mesmo tempo, o Rei de Midland estava conseguindo ir bem ao parar os avanços dos exércitos inimigos, entretanto, depois que parte da aristocracia de Midland o traiu, a situação do Rei ficou completamente insustentável. Assim, o Rei acabou sendo sobrepujado e deposto

Midland é repartida então entre as 3 nações invasores

Para a posterioridade, o período em que Midland ficou sob o controle dessas 3 nações ficou conhecido como os “[[Anos Negros]]” de Midland

## A Grande Guerra

A [[Grande Grande Grande Guerra|Grande Grande Grande Guerra]] é a maior guerra que o mundo já viu, ocorrendo em razão das disputas de poder entre World-Empire, N1 e N2

Boa parte da guerra ocorreu dentro dos limites de Midland, simplesmente devastando a região e sendo responsável pela morte direta ou indireta de milhões dos cidadãos de Midland

## Governo Provisório

Ao fim da Grande Guerra, o [[CWP|Comitê para a Paz Mundial]] (CWP) é criado num esforço mundial em conjunto para a preservação da paz à qualquer custo

Ao CWP é incumbido o encargo de resolver a questão de Midland, já que o tratado que pôs fim à Grande Guerra previa a o fim da partilha de Midland entre as 3 potências. 

Entretanto, em vez de devolver Midland para o povo, o CWP assumiu o governo de Midland sob o pretexto de “governo provisório”, com o suposto objetivo de por ordem na casa antes de devolver Midland para sua população. Entretanto, o carácter provisório  não ocorreu realmente na prática, já que o CPW governou Midland sob regime de exceção por anos. Logo, Midland estava presa numa situação semelhante à terra sem lei. Em razão disso, o caos no país cresceu sem limites, com os números relacionados a fome, a miséria e a doenças crescendo exponencialmente, ao mesmo tempo que a destruição crescia por conta de guerras civis e insurreições populares.  
Não obstante, a situação de anomia contribuiu para o crescimento do número de organizações  criminosas, que eram além de tudo extremamente cruéis e desumanas

Entretanto, como é de praxe, o [[Restauração]] favorecia pessoas que eram apoiadores do regime, constituindo desse modo a nova elite de Midland. Mais tarde, quem fazia parte dessa elite, seria conhecida como “[[Traidores de Sangue]]”

### Revolução das Romãs 

[[Gabriel Bosco]], com o apoio do [[Adam Drake]], funda o [[NML|Movimento Nacional pela Liberdade]] (NML), organização rebelde que buscava o fim do Governo Provisório. Com o Adam como seu comandante militar, o Gabriel parte para o enfrentamento direto contra o governo provisório, momento que ficaria conhecido como [[Revolução das Romãs]] para os contemporâneos

## Ditadura do Scorza

Depois de obter sucesso na revolução, Gabriel assume como governante interino de Midland

Entretanto, diferente do que era esperado, o Gabriel não convocou eleições, já que ele acreditava piamente ser a única pessoa capaz de transformar Midland na maior potência mundial. Usando a sua capacidade nata de discursar para multidões junto com o seu carisma, ele conseguiu convencer o NML a apoiar ele nessa decisão. Ao ver o que o Gabriel planeja fazer, Adam tentou mobilizar a ala da NML que era leal a ele, mas já era tarde demais, Gabriel usou os seus aliados  para acabar com qualquer ala dissonante dentro do NML assim conseguindo o cargo de Líder Supremo de Midland, trocando em miúdos, o Ditador de Midland

Mais tarde, depois que o Gabriel funda a sua polícia secreta de Midland, [[Viola Spencer]] funda o movimento [[We Stand]], com o objetivo de pela libertar Midland da [[Regime do Bosco]]

[[Ditadura do Kirk]] e [[Nicholas Kirk]]

Embora, o Gabriel pudesse ter executado o Adam, ele não o fez, preferindo o exilar de Midland. Depois de ser exilado, Adam vai para World-Empire, onde fica quando ouve falar sobre o We Stand, decidindo assim voltar para Midland e entrar para o We Stand. O Adam luta contra o regime do Gabriel junto do We Stand por meses, quando ele recebe a notícia que a sua esposa que estava grávida havia dado luz ao Noel, preocupado com a saúde e bem-estar da sua esposa e filho recém-nascido, ele pega ambos e resolve voltar para World-Empire, abandonando o We Stand 

### Invasão

Com medo do poderio militar de Midland sob o regime Gabriel, o CWP decide que precisa acabar com isso já, usando do pretexto das barbaridades cometidas pelo regime do Gabriel, o CWP enviou os seus exércitos para derrubar o regime de Gabriel e supostamente libertar a população de Midland   

A invasão, e posterior ocupação militar, do CWP obtém sucesso em todos seus objetos, conseguindo depor o Gabriel e em tese assim libertar a população, constituindo o primeiro governo democrático de Midland

## Ocupação Militar

Com medo que CWP fizesse como anteriormente e não saísse voluntariamente de Midland, Adam Drake pede ao [[Rei Tiberius I]] (que era seu amigo desde pequeno) que atuasse como mediador junto ao CWP, assim garantindo a transição da ocupação militar de Midland, entretanto, o Rei de Weltreich aproveita que o norte de Midland não havia sido ocupado pelo CWP, reúne seu exército e invade Midland, ocupando por completo a região mais norte de Midland, fazendo que o Adam Drake quebrasse qualquer relacionamento com o Rei de Weltreich e voltasse para Midland

## Governo Fantoche

Como é óbvio, embora a ocupação militar de Midland pelo CWP e Weltreich tenha terminado, nenhum dos países realmente queria perder a influência e o poder que detinha sobre Midland, assim desenvolvendo diferentes estratégias para garantir seu podekmmr sobre Midland 

Weltreich transformou North Midland no seu protetorado, fazendo que NM estivesse sempre sob as sombras de Weltreich 

CWP conseguiu que o governo interino de South Midland assinasse acordos e tratados com ele, garantindo assim a sua influência sobre o governo de SM, ou só Midland, já que o governo do SM não reconhecia a independência de NM

Enfim, ambos governos democráticos de Midland eram na verdade governos fantoches controlados pelo CWP e Weltreich respectivamente, que os usava para esconder a verdade da população

### Revolução

Depois da dissolução do We Stand, o Adam volta para Midland e funda a [[Frente Rebelde|Frente Revolucionária pela Libertação de Midland]], ou simplesmente Frente Rebelde, com a ajuda do [[Edmund Metcalfe]]. A Frente Rebelde nasce como a fusão da ala do We Stand que continuou na ativa, movimentos sindicais e outras organizações rebeldes menores

Em razão de algo, o Adam seria nomeado  como o Inimigo Público nº 1 de Midland. Mais tarde, Adam seria emboscado e morreria enquanto lutava contra agentes do SM.