up:: [[Submundo]]
tags:: #organizações 

# Comissão

A Comissão é o corpo governante do [[Submundo]], sendo responsável pela preservação da ordem e norma mesmo que dentro do mundo do crime

A Comissão é a outro lado da moeda do [[CWP]]

## Leis

1. Todo provedor[^1] deve lealdade primeiro a Comissão.
2. Nada nem ninguém está acima da Comissão dentro do Submundo.
3. Todo provedor deve pagar tributos em troca dos serviços da Comissão.

[^1]: Termo que inclui organizações criminosas e criminosos solos 

## Punições 

- Excomunhão 
- Execução 

## Background 

A [[Grande Grande Grande Guerra]] devastou por completo a Europa

Estando mergulhada no mais puro caos, em razão disso tudo, a criminalidade simplesmente explodiu junto da violência

Como não havia nenhum senso de organização ou ordem entre as facções criminosas e criminosos, a Comissão surgiu 