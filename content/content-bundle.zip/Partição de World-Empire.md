up:: [[Mapa do Mundo]]
tags:: #mundo 

# Partição de World-Empire

- Migração em massa de gente do [[World-Empire]]  para [[Midland]] 