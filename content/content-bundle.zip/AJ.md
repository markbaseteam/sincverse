up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas 

# AJ

AJ faz parte do [[The Stench|Stench]]

## Infobox 

**Nome**:: 
**Apelido**:: AJ
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: The Stench 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aparência

O corpo do AJ é deformado com o tanto de cicatrizes que ele carrega do acidente que destruiu a sua vida para sempre

AJ é alto e magro, com compleição delgada. A sua pele era da cor de porcelana, com rosto oval, cabelos loiros e ondulados, olhos verdes, nariz arrebitado, lábios carnudos e avermelhado, cílios compridos e covinhas. Em geral, ele era bonito, embora fosse ligeiramente andrógino 

Ele cobre o seu corpo inteiro com roupas, não deixando nada à mostra. Ele cobre as suas mãos, braços, pernas, torso, pés e quase o seu rosto inteiro, deixando apenas os olhos à mostra 

## Personalidade

AJ sofre de complexo de inferioridade, odiando qualquer pessoa que seja ou que ele acha que é superior a ele. Ele gosta de infligir dor nas pessoas, ele gosta de ver elas implorando por misericórdia

## Background

Quando era adolescente, o AJ pôs fogo numa mansão, mas enquanto tentava fugir ele acabou fiando preso. O fogo rapidamente tomou conta da mansão inteira e ele não conseguiu sair em tempo antes de ser pego pelas chamas. Todo mundo na mansão morreu, menos o AJ, que conseguiu sair em tempo hábil, mas o seu corpo ficou desfigurado com as queimaduras. De acordo com os médicos, ele não morreu por alguma intervenção divina

AJ fede a carne carbonizada. AJ sente dores profundas e precisa constantemente passar hidratante na sua pele. AJ faz uso de drogas para conseguir suportar a dor. AJ dorme numa banheira, pois ele só consegue dormir quando cobre o seu corpo inteiro com água gelada, logo, antes de ir dormir ele enche a banheira de água e gelo