up:: [[Índice de Poderes]]
tags:: #poderes 
user:: [[Akira Chisaki]]

# Paper Crafting

Paper Crafting é o [[Poder|poder]] do [[Akira Chisaki]]

## Descrição 

O seu poder é sobre origamis. Em outras palavras, ele é capaz de dar as qualidades reais do objeto retratado no origami que ele faz. Por exemplo, ele pode fazer cigarras de origami que vão voar ou sapos de origami que vão pular por conta própria. Ele não precisa estar por perto para que o efeito sobre os origamis seja transmitido, pois qualquer origami feito por ele está sob o domínio do seu poder, independente deonde ele esteja. Do mesmo modo, ele pode fazer origamis com quaisquer materiais a sua disposição, sendo capaz de por exemplo dobrar objetos duros no formato de origami

## Análise 

### Eu

COM:: 3
CON:: 5
MAG:: 3
PD:: 4
PO:: 2
PRA:: 4
UTI:: 3
VER:: 4

### Gráfico 

## Veja mais 

[[Análise dos Poderes]] 