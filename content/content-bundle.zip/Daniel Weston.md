up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas 

# Daniel Weston

Irmão mais novo do [[Arthur Weston]] e o irmão mais velho do [[Eli Weston]] 

Faz parte do [[Escudo]]

## Infobox

**Nome**:: Daniel Weston 
**Apelido**::
**Gênero**:: Homem 
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

