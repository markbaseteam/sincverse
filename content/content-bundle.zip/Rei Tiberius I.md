up:: [[Mapa dos Personagens]]
tags:: #personagens/mortos

# Rei Tiberius I

O Rei Tiberius I é hoje o rei do [[World-Empire]]

O Rei é o avô do [[Alex Drake]] e o bisavô do [[Blaise Delacroix]]

O Rei Tiberius I conheceu o [[Adam Drake]] antes de ser coroado Rei enquanto estava na [[Universidade de World-Empire]]

[[Midland]]

## Infobox 

**Nome**:: Tiberius I
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Bi
**Idade**::
**Nascimento**::
**Status**:: Falecido
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**::
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::