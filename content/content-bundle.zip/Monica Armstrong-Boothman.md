up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários  #antagonistas 

# Monica Armstrong-Boothman

Monica Armstrong-Boothman faz parte do [[Escudo]] e é a parceira de treino do [[Thomas Madison]], sendo preparado para o suceder caso algo aconteça com ele

Monica geralmente é parceira do [[Charles Babineaux]] em suas missões 

## Infobox 

**Nome**:: Monica Armstrong-Boothman
**Apelido**::
**Gênero**:: Mulher
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aptidões e poderes

[[Manipulação de Cabelo]]

