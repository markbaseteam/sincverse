up:: [[Mapa dos Antagonistas]]
tags:: #personagens/mortos

# Thomas Starkweather

Thomas é o pai adotivo do [[John Starkweather]] 

Thomas faz parte do [[Exército de Midland]] de [[Midland]] 

## Infobox 

**Nome**:: Thomas Starkweather 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Falecido
**Afiliações-Anteriores**:: Exército de Midland 
**Afiliações-Atuais**:: 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::