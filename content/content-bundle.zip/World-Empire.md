up:: [[Mapa do Mundo]]
tags:: #mundo

# World-Empire

World-Empire é outra nação, claramente inspirada no Império Britânico 

[[Midland]]
[[Rei Tiberius I]]