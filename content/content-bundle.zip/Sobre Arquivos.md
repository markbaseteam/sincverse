up:: [[Cérebro]]

# Sobre Arquivos

A pasta Arquivos contém os arquivos relacionados ao worldbuilding de Vengeance 

## Antagonistas

```dataview
LIST 
FROM #personagens/antagonistas or #organizações/antagonistas 
SORT file.name ASC
```
 
