up:: [[World-Empire]]
tags:: #mundo

# Universidade de World-Empire

[[World-Empire]]

## Ex-Alunos

- [[Adam Drake]] 
- [[Edmund Metcalfe]] 
- [[Viola Spencer]]