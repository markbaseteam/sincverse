up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários  #antagonistas 

# Adrianus

Adrianus é o autointitulado Rei de [[Midland]] 

Hoje, ele é o chefe do [[MRM]] 

## Infobox

**Nome**:: Adrianus
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: MRM
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background

Adrianus descende da [[Casa Adrianus|Casa Real de Midland]] 
Adrianus estava preso no [[Prisão de Segurança Máxima]], mas ele acaba conseguindo fugir durante a [[Fuga da Prisão|fuga em massa]] 