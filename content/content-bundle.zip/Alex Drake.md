---
dg-publish: true
---
up:: [[Mapa dos Personagens]]
tags:: #personagens/principais #protagonistas 

# Alex Drake

Alex Drake é o protagonista do Vengeance 

## Infobox

**Nome**:: Alex Drake
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**:: 20 anos
**Nascimento**:: 980
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background 

Alex nasceu em [[Midland]]

Alex é o filho de [[Noel Drake]] e [[Celine Duguay]], sendo assim o neto do [[Adam Drake]] e do [[Rei Tiberius I]]

Depois da morte do seu pai pelo [[Jude Tepes]], ele é criado pela [[Bailey]], em segredo

Enquanto vivia escondido com a Bailey, ele virou amigo do [[Blaise Delacroix]] 

Depois que o [[Kieran Wood]] assassinou a Bailey, o Alex parte numa jornada em busca da pessoa que ele achava que assassinou o seu pai e a Bailey

Alex junto com a sua patota entra para a [[Frente Rebelde]] onde conhece a sua futura esposa [[Emma Burgess]]

Alex entra para o [[SOC]]

Ao longo da sua jornada dentro do SOC, o Alex enfrenta numerosos associados do [[Escudo]]

- [[Daniel Weston]]
- [[John Starkweather]]
- [[Cain Earnshaw]]
- [[TJ Rutherford]]
- [[Thomas Heatherwick]]

Alex enfrenta o [[Governo de Midland|Governo de Midland]], [[CWP]] e [[World-Empire]] enquanto faz parte da Frente Rebelde 

## Mestres 

- [[Avô do Chisaki]]
- [[Patchwork]] 
- [[Viola Spencer]]

## Relacionamentos 

### Emma Burgess 

Emma Burgess é a futura esposa do Alex Drake

### Alicia Huxley 

[[Alicia Huxley]] é o primeiro interesse romântico do Alex