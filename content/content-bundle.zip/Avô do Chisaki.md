up:: [[Mapa dos Personagens]] 
tags:: #personagens/mortos

# Avô do Chisaki

[[Akira Chisaki]]
[[Alex Drake]] 
[[Midland]]
[[World-Empire]]
[[Blaise Delacroix]]
