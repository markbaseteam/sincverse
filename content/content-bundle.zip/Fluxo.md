up:: [[Mapa dos Conceitos]]
tags:: #mundo/conceitos #magia 

# Fluxo

O Fluxo é o combustível para os Ingenia ou poderes 

- [[Magia]]
- [[Ritmo]]
- Técnicas
	- [[Técnicas Comuns]]
		- [[Técnicas Básicas]]
		- [[Técnicas Avançadas]]
	- [[Poder|Técnicas Únicas]]
		- [[Técnicas Inatas]]
		- [[Técnicas Hereditárias]] 

- Eixos 
	- Parte biológica 
	- Parte espiritual 
	- Parte psicológica 

## Definição

## Propriedades

## Terminologia

### Output Máximo

### Taxa Média