up:: [[Mapa das Organizações]]
tags:: #organizações 

# We Stand

O We Stand é o movimento de resistência fundado pela [[Viola Spencer]], com o objetivo de enfrentar a [[Ditadura do Kirk]]

O We Stand atuava dentro de [[Midland]], buscando depor o [[Nicholas Kirk]] do poder

Espiritualmente, o We Stand é o precursor da [[Frente Rebelde]] 

## Staff 

- [[Adam Drake]]