up:: [[Mapa do Mundo]]
tags:: #mundo

# Revolução das Romãs

[[Midland]] 
[[Adam Drake]] e [[Gabriel Bosco]]
[[Restauração]] 
[[CWP]]
[[NML]]

## Trivia 

- O nome "Revolução das Romãs" remonta ao fato que a polpa da fruta romã é semelhante à sangue 
