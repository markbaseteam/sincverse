up:: [[Mapa dos Conceitos]]
tags:: #mundo/conceitos 

# Ritmo

Ritmo é o campo metafísico que é gerado por todos seres vivos 

A partir do Ritmo, o [[Fluxo]] é produzido, que por sua vez é a fonte para a [[Magia]]

