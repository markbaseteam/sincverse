up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Akira Chisaki

Akira Chisaki é o 

[[Frente Rebelde]]

## Infobox 

**Nome**:: Akira Chisaki 
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Background 

Ele é neto do cara que treinou o Alex Drake em artes marciais 

## Aptidões e Poderes

[[Paper Crafting]]

## Batalhas e combates

- Akira Sasaki VS. **[[Charles Babineaux]] e [[Monica Armstrong-Boothman]]**