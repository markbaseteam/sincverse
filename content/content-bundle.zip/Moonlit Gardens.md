up:: [[Midland]]
tags:: #mundo/lugares 

# Moonlit Gardens

Quando criança o [[Jude Tepes]] tinha medo de acabar indo parar no Moonlit Garden 

Todo mundo da [[Casa Tepes]] que estava num grau avançado do [[Mudblood]] era obrigado a ir viver nos Moonlit Gardens 

