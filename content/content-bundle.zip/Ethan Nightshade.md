up:: [[Mapa dos Antagonistas]]
tags:: #personagens/secundários #antagonistas 

# Ethan Nightshade

Ethan faz parte do [[CWP]]

## Infobox 

**Nome**:: Ethan Nightshade
**Apelido**::
**Gênero**:: Homem
**Sexualidade**:: Gay
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: CWP
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aparência 

Ethan é alto e delgado, com tez da cor de porcelana, rosto oval, cabelos longos e loiros, olhos cor de mel, nariz reto, lábios cheios e cílios compridos. Ele é tão alto graças às suas pernas compridas, embora não seja particularmente musculoso.

Depois de ser torturado e levado ao extremo pelo Jacob, Ethan passa a fazer uso de sombra e batom roxo, vestindo apenas roupas pretas

## Personalidade

Em seu exterior, Ethan parece ser calmo, frio e lógico, demonstrando quase nenhuma emoção. Entretanto, no fundo, ele é volátil e emocionalmente instável

Ethan é apaixonado pelo [[Alex Drake]] num nível patológico, sendo extremamente ciumento, controlador e possessivo

Depois de ser rejeitado pelo Alex pela segunda vez, a mente do Ethan simplesmente quebrou, com o seu amor distorcido sendo transformado num ódio assassino direcionado a quem ele julgava culpado pelas negativas do Alex. Mais tarde, em meio a sua loucura, o Ethan conclui que se ele não poderia ter o Alex, ninguém mais o poderia 

Ao longo da trama, a máscara de apatia e frieza que o Ethan vestia vai aos pouquinhos quebrando, revelando o verdadeiro Ethan, marcado pela sua personalidade disforme

Assim como quase qualquer pessoa que já tenha sofrido algum trauma ao longo da sua vida, o Ethan procurou internalizar tudo que podia, como mecanismo de defesa, entretanto, isso apenas causou ainda mais prejuízos à longo prazo. Sem qualquer ajuda ou suporte, o Ethan acabou desenvolvendo psicose. Embora tentasse fingir que estava tudo OK, quando ele era exposto a situações estressante, ele perdia a capacidade discernir o real do irreal, por vezes chegando a alucinar ou delirar

Ethan é mal educado e sardônico, não respeitando a nada nem a ninguém. Ele é cruel e sanguinário, sentido prazer ao ver e infligir sofrimento aos outros, sendo conhecido pelo apelido carinhoso de "carniceiro". Embora seja ardiloso e astuto, ele é impulsivo e imprudente, significando que em geral ele não elabora planos, dançando conforme a musica. Ethan é genioso, irascível e irritadiço. Ele é egoísta e egocêntrico, acreditando que o mundo deveria ser do jeito que ele quer que seja

## Enredo 

[[Daniel Hawbrough]]

Depois de atitudes suspeitas, ele é investigado pelo [[Adjudicador]] em segredo 

Depois de ser revelado como espião dentro do [[SOC]] e [[Frente Rebelde]], o Ethan brutalmente assassina os policiais da [[LEA]] enviados para o prender e foge em seguida

Ethan sequestrou o Alex por duas vezes 
