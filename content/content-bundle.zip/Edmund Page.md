up:: [[Mapa dos Personagens]]
tags:: #personagens/secundários 

# Edmund Page

[[SOC]]
[[Frente Rebelde]]

## Infobox 

**Nome**:: Edward Page
**Apelido**::
**Gênero**:: Homem 
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Frente Rebelde 
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::

## Aptidões e poderes 


[[Glass]]
