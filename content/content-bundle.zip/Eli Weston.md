up:: [[Mapa dos Antagonistas]]
tags:: #personagens/terciários #antagonistas 

# Eli Weston

Irmão mais novo do [[Arthur Weston]] e do [[Daniel Weston]]

Faz parte do [[Escudo]]

## Infobox 

**Nome**:: Elijah Weston
**Apelido**:: Eli
**Gênero**:: Homem
**Sexualidade**:: Hetero
**Idade**::
**Nascimento**::
**Status**:: Vivo
**Afiliações-Anteriores**:: 
**Afiliações-Atuais**:: Escudo
**Ocupações-Antigas**:: 
**Ocupações-Atuais**::