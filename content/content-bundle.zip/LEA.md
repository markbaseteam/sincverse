up:: [[Suprema Corte da Frente Rebelde]]
tags:: #organizações 

# LEA

A Agência de Execução da Lei (ou simplesmente LEA) é a unidade da [[Frente Rebelde]] que está sob a jurisdição da [[Suprema Corte da Frente Rebelde]] e do [[Adjudicador]] 

A LEA pode ser vista como o braço armado da Su, sendo responsável pela garantia de que as decisões do Adjudicador não vão ser ignoradas.

## Pessoal

- [[Reginald]] -> Diretor da LEA

## Trivia

- O BCW rankeia o Reginald Mason como [[NP#^0827a8|Nível B]]


