up:: [[World-Empire]]
tags:: #organizações #antagonistas 

# Forças Armadas Reais

[[World-Empire]] 
[[Rei Tiberius I]]

[[Exército Real de World-Empire]] 
[[Marinha Real]]
[[Força Aérea Real]]
