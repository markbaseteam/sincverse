up:: [[Submundo]]
tags:: #organizações #submundo

# Clube de Luta

O Clube da Luta é a organização criminosa responsável pela promoção de lutas ilegais entre lutadores associados. Os ringues do Clube da Luta estão espalhados por todos cantos do mundo

Para melhor organizar os embates do Clube de Luta, o manuseio de armas e [[Poder|poderes]] só são permitidas em categorias próprias. Logo, o manuseio de armas ou poderes na categoria em que não lhe é devida irá acarretar a derrota imediata 

## Sistema

Os lutadores são separados em níveis, indo do nível 100 ao nível 0. O nível 100 é o nível mais baixo, sendo ocupado pelos mais fracos ou iniciantes. O nível 0, por sua vez, é o nível mais alto, sendo ocupado pelos mais poderosos e experientes 

Para descer de nível, o lutador precisa ganhar 10 lutas contra oponentes do seu nível, ganhar 15 lutas contra oponentes de algum nível superior ou então ganhar 5 lutas contra oponentes de algum nível inferior. De forma semelhante, para subir de nível, o lutador precisa perder 5 lutas contra oponentes de algum nível superior, perder 10 lutas contra oponentes do seu nível ou então perder 15 lutas contra lutadores de algum nível inferior

As recompensas são inversamente proporcionais ao seu nível, quão menor o nível do lutador, mais ele ganhará caso ganhe a sua luta 

A cada mudança de nível, o número contabilizado de derrotas é zerado

Não é permitido em hipótese alguma que o lutador mate o seu oponente, caso ocorra, o lutador responsável será permanentemente banido 

A punição por perder três vezes consecutivas por W.O. é o banimento do lutador por 24 meses. A mesma punição é aplicada no caso de três derrotas (sem precisar necessariamente ser consecutivas) por quebra de regras  

Para que qualquer luta ocorra, ela deve ser registrada previamente, contendo a data da luta, a alcunha dos lutadores e modalidade da luta 

Cada lutador que deseja lutar no Clube de Luta deve ser cadastrado e catalogado, recebendo ao final do processo o seu ID Card. O ID Card é vitalício e pode ser usado para garantir que o lutador lute em qualquer ringue do Clube de Luta. Vale ressaltar que o lutador só poderá lutar caso mostre o seu ID Card. Caso algum lutador perca o seu ID Card, ele deverá pagar para que outro seja impresso

## Regras

A luta só acaba quando um dos lutadores é nocauteado ou desiste 

A luta só pode ocorrer dentro do ringue, caso algum dos lutadores saia do ringue, o seu oponente deverá esperar ele retornar para o ringue. Entretanto, caso o lutador que está fora do ringue não demonstre qualquer intenção de voltar ao ringue, ele perderá por desistência

No momento do registro de qualquer luta armada, cada um dos lutadores deve declarar quais armas ele pretende, ou não, manejar durante a luta, cabendo ao seu oponente continuar ou não com a luta.  Lembrando que, o lutador não pode manejar qualquer arma sem o prévio aviso. O mesmo não é aplicado aos poderes, ficando a cargo do oponente tentar descobrir qual o poder do lutador. Fora isso, não há quaisquer restrições a respeito da arma que será manejada ou não, desde que a arma em questão não tenha "propriedades mágicas"

Casos envolvendo poderes relacionados a armas na categoria em que armas são proibidas e poderes são permitidos vão ser analisados pontualmente 

O intervalo de tempo máximo em que qualquer lutador pode ficar inativo sem sofrer quaisquer consequências é de 24 meses. Caso não lute em 24 meses, ele subirá de nível, por exemplo, do nível 15 para o nível 16. A partir disso, a cada 24 meses sem lutar, o lutador subirá 1 nível 

## Lutadores famosos 
  
- [[Alex Drake]]
- [[Amos Keen]]- Nível 72 
- [[Benjamin Wheeler]]- Nível 85 (150 vitórias e 0 derrotas) 
- [[William Woodman]] 

## Trivialidades

- Até agora o número de lutadores que atingiu o nível 0 é igual a 14, com atualmente apenas 4 lutadores ocupando o nível 0